﻿using System;

namespace USAImportWorkflowWeb.Models
{
    public class RegViewModel
    {
		
		public string UserName { get; set; }	
		public string Wnsid { get; set; }		
		public string CitrixId { get; set; }		
		public string Doc_Contact { get; set; }
		public string Userrole { get; set; }
		public string Primary_Location { get; set; }
		public string Secondary_Location { get; set; }
		public Boolean IsActive { get; set; }
	}
}
