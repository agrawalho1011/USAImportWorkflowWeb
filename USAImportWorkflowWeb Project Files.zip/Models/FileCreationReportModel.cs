﻿using System;

namespace USAImportWorkflowWeb.Models
{
    public class FileCreationReportModel
    {
        public string FileNumber { get; set; }
        public string Container { get; set; }
        public DateTime? FileReceivedDate { get; set; }
        public DateTime? filecreationdate { get; set; }
        public string createdby { get; set; }
    }
}
