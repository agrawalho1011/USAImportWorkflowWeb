﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Models
{
    public class OfficeMasterViewModel
    {

        public Guid Id { get; set; } = new Guid();
        public string Office { get; set; }
        public string OfficeName { get; set; }
        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;


    }
}
