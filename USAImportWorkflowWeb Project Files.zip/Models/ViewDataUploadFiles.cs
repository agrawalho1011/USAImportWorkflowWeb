﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Models
{
    public class ViewDataUploadFiles
    {
        public string Name { get; set; }
        public string FilePath { get; set; }
        public int Length { get; set; }
        
        public byte[] Content { get; set; }
    }
}
