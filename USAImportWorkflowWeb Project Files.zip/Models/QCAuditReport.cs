﻿using System;

namespace USAImportWorkflowWeb.Models
{
    public class QCAuditReport
    {
        public DateTime QCdate { get; set; }
        public DateTime Processdate { get; set; }
        public string EMP_ID { get; set; }
        public string Name { get; set; }
        public string FileName { get; set; }
        public string HBLNo { get; set; }
        public string QCName { get; set; }
        public string FieldName { get; set; }
        public string L1 { get; set; }
        public string L2 { get; set; }
        public string L3 { get; set; }
        public string L4 { get; set; }
        public string ErrorType { get; set; }
        public string Comments { get; set; }
        public string Office { get; set; }
        public string POL { get; set; }
        public string POD { get; set; }
        public string ICName { get; set; }

    }
}
