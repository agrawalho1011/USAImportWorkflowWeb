﻿namespace USAImportWorkflowWeb.Models
{
    public class IsLoginActiveModel
    {
        public string UserId { get; set; }
        public string IsActive { get; set; }
    }
}
