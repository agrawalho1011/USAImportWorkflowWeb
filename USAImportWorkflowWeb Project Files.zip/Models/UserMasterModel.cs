﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Models
{
    public class UserMasterModel
    {
        public  string Id { get; set; } = Guid.NewGuid().ToString();
        public  string? UserName { get; set; }
        public string? Wnsid { get; set; }
        public string? CitrixId { get; set; }
        public string? Doc_Contact { get; set; }
        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;
    }
}
