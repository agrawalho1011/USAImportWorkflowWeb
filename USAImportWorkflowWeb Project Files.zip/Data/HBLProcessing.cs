﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Data
{
    public class Hblprocessing
    {
        public string ActivtyId { get; set; }
        public string Hblno { get; set; }
        public string UserId { get; set; }
        public string Activity { get; set; }
        public string ActivityStatus { get; set; }
        public string Comment { get; set; }
        public DateTime? UpdateDatetime { get; set; }

        public virtual Hblmaster HblnoNavigation { get; set; }
    }
}
