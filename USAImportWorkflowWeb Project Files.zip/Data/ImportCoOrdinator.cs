﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Data
{
    public class ImportCoOrdinator
    {
        public string ActivityId { get; set; }
        public string Hblno { get; set; }
        public string Activity { get; set; }
        public string ActivityStatus { get; set; }
        public string ActivityComment { get; set; }
        public string UserId { get; set; }
        public DateTime? LastUpdateDateTime { get; set; }

        public virtual Hblmaster HblnoNavigation { get; set; }
        public virtual UserMaster User { get; set; }
    }
}
