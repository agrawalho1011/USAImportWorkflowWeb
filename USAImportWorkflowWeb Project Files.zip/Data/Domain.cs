﻿using System.Collections.Generic;

namespace USAImportWorkflowWeb.Data
{
    public class Domain
    {
        public Domain()
        {
            User = new HashSet<UserMaster>();
        }
        public int DomainId { get; set; }
        public string Domain1 { get; set; }

        public virtual ICollection<UserMaster> User { get; set; }
    }
}
