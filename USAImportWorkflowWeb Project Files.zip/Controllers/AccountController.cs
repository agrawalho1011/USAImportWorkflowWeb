﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using USAImportWorkflowWeb.Data;
using USAImportWorkflowWeb.Models;

namespace USAImportWorkflowWeb.Controllers
{
    
    public class AccountController : Controller
    {
        private readonly UserManager<UserMaster> userManger;
        private readonly SignInManager<UserMaster> signInManager;
        public ApplicationDbContext _ctx;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public AccountController(UserManager<UserMaster> userManger, IHttpContextAccessor httpContextAccessor, SignInManager<UserMaster> signInManager, ApplicationDbContext ctx)
        {
            _httpContextAccessor = httpContextAccessor;
            this.userManger = userManger;
            this.signInManager = signInManager;
            _ctx = ctx;            
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        //Login for Application
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = await signInManager.PasswordSignInAsync(model.CitrixId, model.Password, false, false);
                    if (result.Succeeded)
                    {
                        var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                        //var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                        var userid = _ctx.Users.Where(x => x.CitrixId == model.CitrixId && x.IsActive==true).Select(x => x.Id).FirstOrDefault();
                        if (userid!=null)
                        {
                            var role = _ctx.UserRoles.Where(x => x.UserId == userid).FirstOrDefault();
                            if (role != null)
                            {
                                var role_name = _ctx.Roles.Where(x => x.Id == role.RoleId).FirstOrDefault();
                                if (role_name != null)
                                    if (role_name.Name == "Admin")
                                    {
                                        return RedirectToAction("AdminDashboard", "Admin");
                                    }
                                    else if (role_name.Name == "User")
                                    {
                                        return RedirectToAction("Dashboard", "User");
                                    }
                                    else if (role_name.Name == "QC")
                                    {
                                        return RedirectToAction("QC_Home", "QC");
                                    }
                            }

                        }
                        else
                        {
                            ModelState.AddModelError("", "User is not active");
                        }

                    }
                    else
                    {
                        ModelState.AddModelError("", "Invalid Login Attempt");
                    }
                }
            }
            catch (Exception ex)
            { 
            }         
            return View(model);
        }
        //Logout for application
        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await signInManager.SignOutAsync();
            return RedirectToAction("Login", "Account");
        }
        //Register User
        [HttpGet]
        public IActionResult Register()
        {
            ViewData["Roles"] = _ctx.Roles.Select(x => new RoleMasterModel
            {
                Id = x.Id,
                Name = x.Name

            }).OrderBy(x=>x.Name).ToList();

            return View();
        }
        [HttpPost]
        public async Task<JsonResult> Register([FromBody] RegisterViewModel model)
        {
            string Msg = "";
            if (ModelState.IsValid)
            {               
                var found = _ctx.UserMaster.Where(x => x.Wnsid==model.Wnsid).FirstOrDefault();
                if (found==null)
                {
                    var user = new UserMaster
                    {
                        CitrixId = model.CitrixId,
                        Wnsid = model.Wnsid,
                        UserName = model.UserName,
                        Doc_Contact =model.Doc_Contact
                    };

                    _ctx.UserRoles.Add(new IdentityUserRole<string>
                    {
                        RoleId = model.Userrole,
                        UserId = user.Id,
                    });

                    var result = await userManger.CreateAsync(user);
                    _ctx.SaveChanges();

                    if (result.Succeeded)
                    {
                        //await signInManager.SignInAsync(user, false);
                        // return RedirectToAction("Register", "Account");
                        Msg="User Insert Sucessfully!";
                      
                    }
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                        Msg=error.Description;
                    }
                    //}
                }
                else
                {
                    Msg="User alredy added";
                }
            }
            return Json(Msg);

        }
        // Get Userlist Data
        [HttpPost]
        public  JsonResult GetUserList()
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();

            List<RegViewModel> result = new List<RegViewModel>();
            result = (from u in _ctx.Users
                      join res in _ctx.UserRoles
                      on u.Id equals res.UserId
                      select new RegViewModel
                      {
                          UserName=u.UserName,
                          CitrixId=u.CitrixId,
                          Wnsid=u.Wnsid,
                          Userrole=_ctx.Roles.Where(x => x.Id==res.RoleId).Select(x => x.Name).FirstOrDefault(),
                          Primary_Location=_ctx.OfficeMaster.Where(x => x.Id==_ctx.UserOfficeRelation.Where(x => x.UserId==u.Id &&x.Order==1).Select(x => x.OfficeId).FirstOrDefault()).Select(x => x.OfficeName).FirstOrDefault(),
                          Secondary_Location=_ctx.OfficeMaster.Where(x => x.Id==_ctx.UserOfficeRelation.Where(x => x.UserId==u.Id &&x.Order==2).Select(x => x.OfficeId).FirstOrDefault()).Select(x => x.OfficeName).FirstOrDefault(),
                          Doc_Contact=u.Doc_Contact,
                          IsActive=(bool)(u.IsActive)
                      }).OrderBy(x=>x.UserName).ToList();

            IQueryable<RegViewModel> SortedData = result.AsQueryable();

            try
            {
                if (sortColumn=="primary_Location")
                {
                    SortedData= sortColumnDirection == "asc" ? SortedData.OrderBy(s => s.Primary_Location) : SortedData.OrderByDescending(s => sortColumn);
                }
                else if(sortColumn=="userName")
                {
                    SortedData= sortColumnDirection == "asc" ? SortedData.OrderBy(s => s.UserName) : SortedData.OrderByDescending(s => sortColumn);
                }
                else if (sortColumn=="secondary_Location")
                {
                    SortedData= sortColumnDirection == "asc" ? SortedData.OrderBy(s => s.Secondary_Location) : SortedData.OrderByDescending(s => sortColumn);
                }


                //if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                //    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();

            }
            catch { }


            int totalRecord = 0;
            int filterRecord = 0;           

            
            var returnObj = new
            {
                data = SortedData
            };

            return Json(returnObj);
        }

        
    }
}
