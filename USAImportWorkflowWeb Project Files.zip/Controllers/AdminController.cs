﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Security.Claims;
using System.Threading.Tasks;
using USAImportWorkflowWeb.Data;
using USAImportWorkflowWeb.Helper;
using USAImportWorkflowWeb.Models;
using USAImportWorkflowWeb.Views.Admin;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;

namespace USAImportWorkflowWeb.ControllersDa
{
    [Authorize]
    public class AdminController : Controller
    {
        private readonly UserManager<UserMaster> userManger;
        private readonly SignInManager<UserMaster> signInManager;
        public ApplicationDbContext _ctx;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IHostingEnvironment hostingEnvironment;
        public AdminController(ApplicationDbContext ctx, IHttpContextAccessor httpContextAccessor, UserManager<UserMaster> userManger, SignInManager<UserMaster> signInManager, IHostingEnvironment _hostingEnvironment)
        {
            userManger = userManger;
            this.signInManager = signInManager;
            hostingEnvironment = _hostingEnvironment;
            _httpContextAccessor = httpContextAccessor;
            _ctx = ctx;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult AdminDashboard(FileMasterViewModel model)
        {
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive==true).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName

            }).OrderBy(x=>x.UserName).ToList();

            return View(model);
        }

        //Get File Master Datatable  
        public JsonResult GetDashboard(string fileNo, string container, string statusId, string userId,
          string office, string hblstatus, string eta_d)
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            IQueryable<FileMaster> data = _ctx.Set<FileMaster>().AsQueryable();
            IQueryable<UserMaster> udata = _ctx.Set<UserMaster>().AsQueryable();
            //IQueryable<QcMaster> qcdata = _ctx.Set<QcMaster>().AsQueryable();
            IQueryable<OfficeMaster> odata = _ctx.Set<OfficeMaster>().AsQueryable();

            int totalRecord = 0;
            int filterRecord = 0;
            //var draw = Request.Form["draw"].FirstOrDefault();
            totalRecord = data.Count();
            string key = "";
            string value = "";
            Boolean searchflag = false;
            Boolean sortflag = false;
            List<FileMasterViewModel> result = new List<FileMasterViewModel>(); 

            result = data.Select(x => new FileMasterViewModel
                {
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    RecievedDate = x.RecievedDate,
                    UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                    Hblstatus = x.Hblstatus,
                    FileComplitionDate = x.FileComplitionDate,
                    Hblcount = x.Hblcount,
                    Eta = x.Eta,
                    EtaChangedBy = udata.Where(y => y.Wnsid == x.EtaChangedBy).Select(y => y.UserName).First(),
                    Office = odata.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                    CreateDateTime = x.CreateDateTime,
                    PreviousEta=x.PreviousEta,
                    EtaChangedDatetime = x.EtaChangedDatetime,
                    EtaChangedComment = x.EtaChangedComment,
                    QcStatus=x.QcStatus
                }).ToList();

            IQueryable<FileMasterViewModel> SortedData = result.AsQueryable();

            if (!string.IsNullOrEmpty(fileNo))
            {
                SortedData = SortedData.Where(x => x.FileNumber == fileNo);

            }
            if (!string.IsNullOrEmpty(container))
            {
                SortedData = SortedData.Where(x => x.Container == container);

            }
            if (!string.IsNullOrEmpty(hblstatus) && hblstatus != "--select--")
            {
                SortedData = SortedData.Where(x => x.Hblstatus == hblstatus);

            }
            if (!string.IsNullOrEmpty(userId) && userId != "--select--")
            {
                var userName = _ctx.UserMaster.Where(x => x.Id == userId).Select(x => x.UserName).FirstOrDefault();
                SortedData = SortedData.Where(x => x.UserId == userName);

            }
            if (!string.IsNullOrEmpty(office) && office != "--select--")
            {
                SortedData = SortedData.Where(x => x.Office == office);

            }
            if (!string.IsNullOrEmpty(eta_d))
            {
                SortedData = SortedData.Where(x => x.Eta == Convert.ToDateTime(eta_d));

            }

            if (!string.IsNullOrEmpty(searchValue))
            {
                if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
                    searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12" || searchValue == "eta18")
                {
                    if (searchValue == "eta10")
                    {
                        SortedData = SortedData.Where(x => x.Eta != null && Convert.ToDateTime(x.Eta).AddDays(-10) <= DateTime.Now && (x.Hblstatus != "Completed"));

                    }
                    else if (searchValue == "eta12")
                    {
                        SortedData = SortedData.Where(x => x.Eta != null && Convert.ToDateTime(x.Eta).AddDays(-10) > DateTime.Now && Convert.ToDateTime(x.Eta).AddDays(-12) <= DateTime.Now && x.Hblstatus != "Completed");
                    }
                    else if (searchValue == "eta18")
                    {
                        SortedData = SortedData.Where(x => x.Eta != null && Convert.ToDateTime(x.Eta).AddDays(-12) > DateTime.Now && x.Hblstatus != "Completed");
                    }
                    else if (searchValue == "UnAllocated")
                    {
                        searchValue = null;
                        SortedData = SortedData.Where(x => x.Hblstatus == searchValue);
                    }
                    else
                    {
                        SortedData = SortedData.Where(x => x.Hblstatus == searchValue);
                    }
                }

            }

            try
            {

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
                sortflag=false;
            }
            catch { }

           
            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = SortedData.Count(),
                data = SortedData.Skip(skip).Take(pageSize == -1 ? 100 : pageSize).ToList(),//result
                skip = skip,
                pageSize = pageSize,
            };
            return Json(returnObj);
        }

        public IActionResult GetUser(UserMasterModel model)
        {
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive==true).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName

            }).OrderBy(x=>x.UserName).ToList();
            return View();
        }
        public IActionResult AddUser(RegisterViewModel model)
        {
            ViewData["Roles"] = _ctx.Roles.Select(x => new RoleMasterModel
            {
                Id = x.Id,
                Name = x.Name

            }).OrderBy(x=>x.Name).ToList();
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive==true).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName

            }).OrderBy(x=>x.UserName).ToList();

            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x=>x.OfficeName).ToList();

            return View(model);
        }
        //User Registration
        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var user = new UserMaster
                    {
                        CitrixId = model.CitrixId,
                        Wnsid = model.Wnsid,
                        UserName = model.CitrixId,
                        Doc_Contact = model.Doc_Contact
                    };
                    _ctx.UserRoles.Add(new IdentityUserRole<string>
                    {
                        RoleId = model.Userrole,
                        UserId = user.Id,
                    });

                    var result = await userManger.CreateAsync(user);
                    _ctx.SaveChanges();
                    if (result.Succeeded)
                    {
                        //await signInManager.SignInAsync(user, false);
                        return RedirectToAction("Login", "Account");
                    }
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                }
            }
            catch (Exception)
            {

            }
            return View(model);
        }
        public IActionResult AddOffices()
        {
            return View();
        }
        //Add Office
        [HttpPost]
        public async Task<IActionResult> AddOffices(OfficeMasterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var result = _ctx.OfficeMaster.Where(x => x.OfficeName == model.OfficeName).FirstOrDefault();
                if (result != null)
                {

                }
                else
                {
                    _ctx.OfficeMaster.Add(new OfficeMaster
                    {
                        OfficeName = model.OfficeName,

                    });
                    _ctx.SaveChanges();
                }
            }
            return View(model);
        }

        public IActionResult AddUserWiseOfficeRelation()
        {
            ViewData["Roles"] = _ctx.Roles.Select(x => new RoleMasterModel
            {
                Id = x.Id,
                Name = x.Name

            }).OrderBy(x=>x.Name).ToList();
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive==true).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName

            }).OrderBy(x=>x.UserName).ToList();

            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x=>x.OfficeName).ToList();

            ViewData["OfficesRelation"] = _ctx.UserOfficeRelation.Select(x => new UserOfficeRelationViewModel
            {
                Id = x.Id,
                OfficeId = x.OfficeId,
                UserId = x.UserId

            }).ToList();

            return View();
        }
        //Add User Wise Office Relation
        [HttpPost]
        public JsonResult AddUserWiseOfficeRelation([FromBody]AddUserwiseOfficeLocationCS model)
        {
            string Msg = "";
            ViewData["Roles"] = _ctx.Roles.Select(x => new RoleMasterModel
            {
                Id = x.Id,
                Name = x.Name
            }).OrderBy(x=>x.Name).ToList();
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive==true).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName

            }).OrderBy(x=>x.UserName).ToList();

            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x=>x.OfficeName).ToList();

            ViewData["OfficesRelation"] = _ctx.UserOfficeRelation.Select(x => new UserOfficeRelationViewModel
            {
                Id = x.Id,
                OfficeId = x.OfficeId,
                UserId = x.UserId

            }).ToList();

            var found = _ctx.UserOfficeRelation.Where(x => x.UserId == model.UserId  && x.Order ==Convert.ToInt16(model.Order)).FirstOrDefault();

            if (found == null)
            {
                _ctx.UserOfficeRelation.Add(new UserOfficeRelation
                {
                    //Id =Guid.Parse( model.Id),
                    OfficeId =Guid.Parse( model.OfficeId.ToString()),
                    UserId = model.UserId,
                    IsActive = true,
                    Order =Convert.ToInt16( model.Order)

                });
                _ctx.SaveChanges();
                Msg="User Office Relation Add";
            }
            else
            {
                var rowsModified = _ctx.Database.ExecuteSqlRaw($"UPDATE [UserOfficeRelation] SET [OfficeId] ='"+model.OfficeId+"',[Order]='"+model.Order+"' WHERE [Id]='"+found.Id+"' and [UserId]='"+model.UserId+"'");
                _ctx.SaveChanges();
                Msg="User Office Relation Update";

            }

            return Json(Msg);
        }

        public IActionResult AssignRole()
        {
            ViewData["Roles"] = _ctx.Roles.Select(x => new RoleMasterModel
            {
                Id = x.Id,
                Name = x.Name

            }).OrderBy(x=>x.Name).ToList();
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive==true).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName

            }).OrderBy(x=>x.UserName).ToList();

            return View();
        }

        //Assign Role to User
        [HttpPost]
        public JsonResult AssignRole([FromBody] UserRoleViewModel model)
        {
            string Msg = "";
            ViewData["Roles"] = _ctx.Roles.Select(x => new RoleMasterModel
            {
                Id = x.Id,
                Name = x.Name

            }).OrderBy(x => x.Name).ToList();
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive==true).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName

            }).OrderBy(x => x.UserName).ToList();
            if (model.UserId=="Select")
            {
                Msg="Please select User";
            }
            else if (model.RoleId=="Select")
            {
                Msg="Please select Role";
            }
            else
            {
                var urole = _ctx.UserRoles.Where(x => x.UserId==model.UserId);
                if (urole.Count()==0)
                {
                    _ctx.UserRoles.Add(new IdentityUserRole<string>
                    {
                        RoleId = model.RoleId,
                        UserId = model.UserId,
                    });
                    _ctx.SaveChanges();
                    Msg="User role assign sucessfully.";
                }
                else
                {
                    _ctx.Database.ExecuteSqlRaw($"UPDATE [UserRoles] SET [RoleId] ='"+model.RoleId+"' WHERE [UserId]='"+model.UserId+"'");
                    _ctx.SaveChanges();
                    Msg="User role change sucessfully.";

                }

            }
            return Json(Msg);
        }

        //Is Login active 
        [HttpPost]
        public JsonResult IsLoginActive([FromBody] IsLoginActiveModel model)
        {
            string Msg = "";
            try
            {
                if (model!=null)
                {
                    var wnsid = _ctx.Users.Where(x => x.Wnsid == model.UserId).Select(x => x.Wnsid).SingleOrDefault();
                    UserMaster user = _ctx.UserMaster.Where(x => x.Wnsid==wnsid).FirstOrDefault();
                    Boolean status = Convert.ToBoolean(model.IsActive);
                    if (model.IsActive=="true")
                    {
                        user.IsActive=false;
                        Msg="User is De-Active Update Sucessfully";
                    }
                    else
                    {
                        user.IsActive=true;
                        Msg="User is Active Update Sucessfully";
                    }
                    _ctx.UserMaster.Update(user);
                    _ctx.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                Msg=ex.Message;
            }
            return Json(Msg);
        }

        //Add File
        public IActionResult Insert_File(string Msg)
        {
            if (Msg=="File Added Successfully!")
            {
                ViewData["Msg"] = Msg;
            }
            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).OrderBy(x=>x.OfficeName).ToList();
            return View();
        }
        //Insert File into Database
        [HttpPost]
        public JsonResult Insert_FileDB([FromBody] InsertFileMaster file)
        {
            string Msg = "";
            try
            {
                var found = _ctx.FileMaster.Where(x => x.FileNumber == file.FileNumber).FirstOrDefault();
                var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                string userId = _ctx.Users.Where(x => x.Id == userid).FirstOrDefault().UserName;
                var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
                if (found == null)
                {
                    FileMaster FM = new FileMaster
                    {
                        FileNumber = file.FileNumber.Trim(),
                        Container = file.Container.Trim(),
                        Hblcount = file.Hblcount,
                        RecievedDate =file.RecievedDate=="" ? null : Convert.ToDateTime(file.RecievedDate),
                        Eta =file.Eta=="" ? null : Convert.ToDateTime(file.Eta),
                        Office =file.Office,
                        UserId = userid,
                        ContactPerson=file.ContactPerson,
                        QcStatus="",
                        Pol=file.Pol.Trim(),
                        Pod=file.Pod.Trim(),
                        CreateDateTime=DateTime.Now
                    };
                    var res = _ctx.FileMaster.Add(FM);
                    _ctx.SaveChanges();
                    Msg = "File Insert Successfully!";
                }
                else
                {
                    Msg = "File is already Inserted.";

                }
            }
            catch (Exception ex)
            {

            }
            return Json(Msg);
        }
        //Change File Status
        [HttpPost]
        public JsonResult ChangeStatus([FromBody] FileMasterViewModel file)
        {
            string Msg = "";

            if (file!=null)
            {
                var found = _ctx.FileMaster.Include(x => x.Hblmaster).Where(x => x.FileNumber == file.FileNumber).FirstOrDefault();

                if (found!=null)
                {
                    if (found.Hblstatus=="Completed" && file.Hblstatus=="Completed")
                    {
                        Msg="Filestatus already completed.";
                        foreach (var hbl in found.Hblmaster)
                        {
                            hbl.HblprocessingStatus=file.Hblstatus;
                            hbl.HblprocessingDate=DateTime.Now;
                            hbl.Amsstatus=file.Hblstatus;
                            hbl.AmsprocessingDate=DateTime.Now;
                            hbl.InvoicingStatus=file.Hblstatus;
                            hbl.InvoicingDate= DateTime.Now.ToString();

                        }
                        found.QcStatus="Send to Qc";
                        _ctx.FileMaster.Update(found);
                        _ctx.SaveChanges();
                    }
                    else
                    {
                        if (file.Hblstatus=="Completed")
                        {
                            found.Hblstatus=file.Hblstatus;
                            found.FileComplitionDate=DateTime.Now;
                            found.QcStatus="Send to Qc";
                        }
                        else
                        {
                            if (found.Hbluser==""||found.Hbluser==null)
                            {
                                Msg="File is not allocated";
                            }
                            else
                            {
                                found.Hblstatus=file.Hblstatus;
                                found.FileComplitionDate=DateTime.Now;
                                found.QcStatus="";
                                found.Icuser="";
                            }
                        }

                        if (Msg=="File is not allocated")
                        {

                        }
                        else
                        {
                            _ctx.FileMaster.Update(found);
                            _ctx.SaveChanges();

                            foreach (var hbl in found.Hblmaster)
                            {
                                hbl.HblprocessingStatus=file.Hblstatus;
                                hbl.HblprocessingDate=DateTime.Now;
                                hbl.Amsstatus=file.Hblstatus;
                                hbl.AmsprocessingDate=DateTime.Now;
                                hbl.InvoicingStatus=file.Hblstatus;
                                hbl.InvoicingDate= DateTime.Now.ToString();
                            }
                            _ctx.FileMaster.Update(found);
                            _ctx.SaveChanges();
                            Msg="File status Update Sucessfully";
                        }

                    }

                }
            }
            return Json(Msg);
        }


        //Upload Template for ETA changed

        [HttpPost]
        public IActionResult UploadDataForEta(IFormFile formFile)
        {
            try
            {
                if (formFile != null)
                {
                    var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                    var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                    string userId = _ctx.Users.Where(x => x.Id == userid).FirstOrDefault().UserName;
                    var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
                    var fileName = Path.GetFileName(formFile.FileName);
                    var uploads = Path.Combine(hostingEnvironment.WebRootPath, "uploads");
                    if (!Directory.Exists(uploads))
                        Directory.CreateDirectory(uploads);

                    var filePath = Path.Combine(uploads, fileName);
                    using (var dispose = new FileStream(filePath, FileMode.Create))
                    {
                        formFile.CopyTo(dispose);

                    }
                    DataTable xldata = ExcelFunction.GetDataFromExcel(filePath);
                    xldata.Columns.Add("Status");

                    //DataTable dtt = new DataTable();
                    //dtt.Columns.Add("File#");
                    //dtt.Columns.Add("Container#");
                    //dtt.Columns.Add("Eta#");

                    foreach (DataRow dr in xldata.Rows)
                    {
                        try
                        {
                            FileMaster file = _ctx.FileMaster.Where(x => x.FileNumber==dr[0].ToString()).FirstOrDefault();
                            if (file!=null)
                            {
                                if (file.QcStatus!="Completed")
                                {
                                    if (file.Eta.ToString()!="")
                                    {
                                        if (file.Eta==Convert.ToDateTime(dr[2].ToString()).Date)
                                        {
                                            dr[3]="ETA is Same";
                                        }
                                        else
                                        {
                                            file.PreviousEta=file.Eta;
                                            file.EtaChangedBy=wnsid;
                                            file.EtaChangedDatetime=DateTime.Now;
                                            file.Eta=Convert.ToDateTime(dr[2].ToString()).Date;
                                            _ctx.FileMaster.Update(file);
                                            _ctx.SaveChanges();
                                            dr[3]="Completed";
                                        }

                                    }
                                    else
                                    {
                                        dr[3]="File ETA is empty";
                                    }

                                }
                                else
                                {
                                    dr[3]="ETA is not change because of file QCStatus is Completed ";
                                }
                            }
                            else
                            {
                                dr[3]="File number is not found";
                            }

                        }
                        catch (Exception ex)
                        {
                            dr[3]=ex.Message;
                        }

                    }

                    // string apath = filename + ".xlsx";
                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        xldata.TableName = "ETAchanged";
                        var wsETAchange = wb.Worksheets.Add(xldata);

                        try
                        {
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelname = $"ETA_Report-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }
                        }
                        catch (Exception ex)
                        {

                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("AdminDashboard", "Admin");
        }

        //File Upload Data
        [HttpPost]
        public IActionResult UploadData(IFormFile formFile)
        {
            try
            {
                if (formFile != null)
                {
                    var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                    var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                    string userId = _ctx.Users.Where(x => x.Id == userid).FirstOrDefault().UserName;
                    var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
                    var fileName = Path.GetFileName(formFile.FileName);
                    var uploads = Path.Combine(hostingEnvironment.WebRootPath, "uploads");
                    if (!Directory.Exists(uploads))
                        Directory.CreateDirectory(uploads);

                    var filePath = Path.Combine(uploads, fileName);
                    using (var dispose = new FileStream(filePath, FileMode.Create))
                    {
                        formFile.CopyTo(dispose);

                    }
                    DataTable xldata = ExcelFunction.GetDataFromExcel(filePath);

                    DataTable dtt = new DataTable();
                    dtt.Columns.Add("File#");
                    dtt.Columns.Add("Container#");
                    dtt.Columns.Add("MBL#");
                    dtt.Columns.Add("UnitDisposition");
                    dtt.Columns.Add("DepFile");
                    dtt.Columns.Add("Vessel");
                    dtt.Columns.Add("Terminal");

                    List<Hblmaster> addhbls = new List<Hblmaster>();
                    List<string> disp = _ctx.DispositionMaster.Select(x => x.Name).ToList();
                    List<string> dipfile = _ctx.OfficeMaster.Where(x => x.IsActive == true && x.IsDelete == false).Select(x => x.OfficeName.Replace(Environment.NewLine, String.Empty)).ToList();
                    foreach (DataRow dr in xldata.Rows)
                    {

                        if ((dr["File"].ToString() != "" || dr["File"].ToString() != null) && disp.Contains(dr["UnitDisp"].ToString().ToUpper().Trim()) == true
                            && dipfile.Contains(dr["DepFile"]) == true && dr["Product"].ToString() == "LCL")
                        {
                            var duplicate = _ctx.FileMaster.Where(x => x.FileNumber == dr["File"].ToString().Trim() && (x.Hblstatus != "Completed"||x.Hblstatus == null)).FirstOrDefault();

                            if (duplicate != null)
                            {
                                duplicate.FileNumber = dr["File"].ToString().Trim();
                                duplicate.Container = dr["Cont Nr"].ToString().Trim();
                                duplicate.Pol = dr["POL"].ToString().Trim();
                                duplicate.Pod = dr["POD"].ToString().Trim();
                                duplicate.Mbl = dr["MasterBL"].ToString().Trim();
                                duplicate.UnitDispo = dr["UnitDisp"].ToString().Trim();
                                duplicate.DepFile = dr["DepFile"].ToString().Trim();
                                duplicate.ShippingLine = dr["ShipLine"].ToString().Trim();
                                duplicate.Cfs = dr["Devanning CFS"].ToString().Trim();
                                duplicate.Vessel = dr["Vessel"].ToString().Trim();
                                duplicate.Terminal = dr["Terminal"].ToString().Trim();

                                if (duplicate.Eta != Convert.ToDateTime(dr["Eta"]))
                                {
                                    duplicate.PreviousEta = duplicate.Eta == null ? null : duplicate.Eta;
                                    duplicate.Eta = Convert.ToDateTime(dr["Eta"]);
                                    duplicate.EtaChangedComment = "ETA changed through Web report.";
                                }
                                _ctx.FileMaster.Update(duplicate);

                                var dup = _ctx.Hblmaster.Where(x => x.Hblno == dr["BL"].ToString().Trim()).FirstOrDefault();
                                if (dup == null)
                                {
                                    duplicate.Hblmaster.Add(new Hblmaster
                                    {
                                        FileNumber = dr["File"].ToString().Trim(),
                                        Hblno = dr["BL"].ToString().Trim(),
                                        Pod = dr["POD"].ToString().Trim(),
                                        Pld=dr["POL"].ToString().Trim(),
                                        UserId=userId,
                                        CreateDate=DateTime.Now

                                    });
                                    _ctx.SaveChanges();
                                }
                            }
                            else
                            {
                                DataRow row = dtt.NewRow();
                                row["File#"] = dr["File"].ToString().Trim();
                                row["Container#"] = dr["Cont Nr"].ToString().Trim();
                                row["MBL#"] = dr["MasterBL"].ToString().Trim();
                                row["UnitDisposition"] = dr["UnitDisp"].ToString().Trim();
                                row["DepFile"] = dr["DepFile"].ToString().Trim();
                                row["Vessel"] = dr["Vessel"].ToString().Trim();
                                row["Terminal"] = dr["Terminal"].ToString().Trim();
                                dtt.Rows.Add(row);

                            }
                        }
                    }
                    XLWorkbook wb = new XLWorkbook();
                    wb.Worksheets.Add(dtt, "Report");
                    //wb.SaveAs(System.Windows.Forms.Application.StartupPath + "\\Output\\Report_" + DateTime.Now.ToString("ddMMMyyyy") + "_" + DateTime.Now.ToString("hhmmss") + ".xlsx");

                    // System.Windows.MessageBox.Show("File uploaded successfully  && Report saved on " + System.Windows.Forms.Application.StartupPath + "\\Output\\Report_" + DateTime.Now.ToString("ddMMMyyyy") + "_" + DateTime.Now.ToString("hhmmss") + ".xlsx");

                }
            }
            catch (Exception ex)
            {
            }
            return RedirectToAction("AdminDashboard", "Admin");
        }



        //Get Dashboardvalue
        public JsonResult GetDashboardValue()
        {
            //var draw = Request.Form["draw"].FirstOrDefault();
            var result = _ctx.FileMaster.ToList();
            AdminDashboardModel model = new AdminDashboardModel
            {

                Received = result.Count,
                Pending = result.Where(x => x.Hblstatus == "Pending").ToList().Count,
                WIP = result.Where(x => x.Hblstatus == "WIP").ToList().Count,
                Query = result.Where(x => x.Hblstatus == "Query").ToList().Count,
                Completed = result.Where(x => x.Hblstatus == "Completed").ToList().Count,
                UnAllocated = result.Where(x => x.Hblstatus == "" ||x.Hblstatus==null).ToList().Count,
                eta10 = result.Where(x => x.Eta != null && Convert.ToDateTime(x.Eta).AddDays(-10) <= DateTime.Now && (x.Hblstatus != "Completed")).Count(),
                eta12 = result.Where(x => x.Eta.Value.AddDays(-10) > DateTime.Now && x.Eta.Value.AddDays(-12) <= DateTime.Now && (x.Hblstatus == null || x.Hblstatus == "WIP")).Count(),
                eta18 = result.Where(x => x.Eta.Value.AddDays(-12) > DateTime.Now && (x.Hblstatus == null || x.Hblstatus == "WIP")).Count(),

            };
            //var jsonString = JsonConvert.SerializeObject(model);
            return Json(model);
        }

        public IActionResult FileEdit(string id)
        {
            FileMasterViewModel _FileMasterViewModel = new FileMasterViewModel();
            if (id!=null)
            {
                id = id.Replace('/', ' ').Trim();

                try
                {
                    var result = _ctx.FileMaster.FirstOrDefault(x => x.FileNumber == id);

                    _FileMasterViewModel = new FileMasterViewModel()
                    {
                        FileNumber = result.FileNumber,
                        Container = result.Container,
                        Hblcount = result.Hblcount,
                        RecievedDate = result.RecievedDate,
                        Office = result.Office,
                        Eta = result.Eta,
                        Pod=result.Pod,
                        Pol=result.Pol
                    };

                    ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
                    {
                        Id = x.Id,
                        OfficeName = x.OfficeName

                    }).ToList();
                }
                catch (Exception ex)
                {

                }
            }
            return View(_FileMasterViewModel);
        }
        //Get all Offices
        public IActionResult getoffices()
        {
            try
            {
                var result = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
                {
                    Id = x.Id,
                    OfficeName = x.OfficeName

                }).OrderBy(x=>x.OfficeName).ToList();
                ViewData["offices"] = result;
            }
            catch (Exception ex)
            {

            }
            return View();
        }
        //File Edit Update 
        public JsonResult FileEditUpdate([FromBody] InsertFileMaster model, string id)
        {
            string Msg = "";
            try
            {
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
                if (model!=null)
                {
                    string ids = _httpContextAccessor.HttpContext.Request.Query["id"];


                    FileMaster file = _ctx.FileMaster.Where(x => x.FileNumber == ids).FirstOrDefault();
                    
                    if ((file.Hblstatus=="Completed"||file.Hblstatus=="Pending") && file.QcStatus=="Completed")
                    {
                        Msg="File is already "+file.Hblstatus+" So don't changes in file.";
                    }
                    else
                    {
                        if (file.FileNumber==model.FileNumber)
                        {

                            file.Container = model.Container;
                            if (Convert.ToDateTime(file.Eta).Date==Convert.ToDateTime(model.Eta).Date)
                            {

                            }
                            else
                            {
                                file.PreviousEta=file.Eta;
                                file.Eta =Convert.ToDateTime(model.Eta);
                                file.NewEta=Convert.ToDateTime(model.Eta);
                                file.EtaChangedBy=wnsid;
                                file.EtaChangedDatetime=DateTime.Now;
                            }
                            file.RecievedDate =Convert.ToDateTime(model.RecievedDate);
                            file.Hblcount = model.Hblcount;
                            file.Office = model.Office;
                            file.Pod=model.Pod;
                            file.Pol=model.Pol;

                            _ctx.FileMaster.Update(file);
                            _ctx.SaveChanges();
                            Msg="file update sucessfully";
                        }
                        else
                        {
                            //string storedproc = "exec UpdateFileMaster "+
                            //               "@FileNumber='"+model.FileNumber+"'," +
                            //               "@Pod='"+model.Pod+"'," +
                            //               "@Pol='"+model.Pol+"'," +
                            //               "@Hblcount='"+model.Hblcount+"'," +
                            //               "@Container='"+model.Container+"'," +                                          
                            //               "@RecievedDate='"+model.RecievedDate+"'," +
                            //               "@Eta='"+model.Eta +"'," +
                            //               "@Office='"+model.Office+"'," +
                            //               "@PriviousFileno='"+id+"'";

                            //_ctx.FileMaster.FromSqlRaw(storedproc).ToListAsync();

                            var rowsModified = _ctx.Database.ExecuteSqlRaw($"UPDATE [FileMaster] SET [FileNumber] ='"+model.FileNumber+"',[Hblcount]='"+model.Hblcount+"',[Container]='"+model.Container+"',[Pod]='"+model.Pod+"',[Pol]='"+model.Pol+"',[RecievedDate]='"+model.RecievedDate+"',[Eta]='"+model.Eta+"',[Office]='"+model.Office+"' WHERE [FileNumber]='"+id+"'");
                            _ctx.SaveChanges();
                            if (rowsModified==1)
                            {
                                Msg="file update sucessfully";
                            }
                            else
                            {
                                Msg="file is not update";
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return Json(Msg);
        }


        [HttpPost]
        public IActionResult FileUpdate(FileMasterViewModel model)
        {
            try
            {
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
                if (model!=null)
                {
                    FileMaster file = _ctx.FileMaster.Where(x => x.FileNumber == model.FileNumber||x.Container==model.Container).FirstOrDefault();


                    if (file.Eta==model.Eta)
                    {

                    }
                    else
                    {
                        file.PreviousEta=file.Eta;
                        file.Eta = model.Eta;
                        file.NewEta=model.Eta;
                        file.EtaChangedBy=wnsid;
                        file.EtaChangedDatetime=DateTime.Now;
                    }

                    file.RecievedDate = model.RecievedDate;
                    file.Hblcount = model.Hblcount;
                    file.Office = model.Office;
                    file.Pod=model.Pod.Trim();
                    file.Pol=model.Pol.Trim();

                    _ctx.FileMaster.Update(file);
                    _ctx.SaveChanges();

                }
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("AdminDashboard", "Admin");
        }
        //File Allocate to User
        [HttpPost]
        public JsonResult FileAllocate([FromBody] FileMasterViewModel model)
        {
            string Msg = "";
            try
            {
                var userid = _ctx.Users.Where(x => x.Id == model.UserId).Select(x => x.Wnsid).FirstOrDefault();
                var fileno = _ctx.FileMaster.Where(x => x.FileNumber == model.FileNumber).FirstOrDefault();
                if (fileno != null)
                {
                    fileno.Hblstatus = "WIP";
                    fileno.Hbluser = userid;
                }
                _ctx.FileMaster.Update(fileno);
                _ctx.SaveChanges();
                Msg="File is allocated to "+userid;
            }
            catch (Exception ex)
            {

            }
            return Json(Msg);
        }

        public IActionResult fileDeAllocate(string Filenumber)
        {
            try
            {
                var fileno = _ctx.FileMaster.Where(x => x.FileNumber == Filenumber).FirstOrDefault();
                if (fileno != null)
                {
                    fileno.Hblstatus = null;
                    fileno.Hbluser = null;
                    fileno.FileStartTime = null;
                    fileno.FileComplitionDate = null;
                    fileno.QcStatus = null;
                    fileno.Icuser = null;
                }
                _ctx.FileMaster.Update(fileno);
                _ctx.SaveChanges();
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("AdminDashboard", "Admin");
        }

        [HttpPost]
        public List<OfficeMaster> GetCountriesName()
        {
            var lst = _ctx.OfficeMaster.Select(x => new OfficeMaster
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).ToList();
            return lst;
        }

        //Insert Role
        [HttpPost]
        public IActionResult Insert_Role(RoleMasterModel model)
        {
            var found = _ctx.Roles.Select(x => x.Name == model.Name).FirstOrDefault();

            if (found==false)
            {
                RoleMasterModel role = new RoleMasterModel();

                role.Name = model.Name;

                _ctx.Roles.Add(new IdentityRole() { Id = role.Id, Name = role.Name });
                _ctx.SaveChanges();
                model = new RoleMasterModel();
            }

            return View(model);
        }
        public IActionResult Insert_Role()
        {
            return View();
        }

        public IActionResult PreAlert(PreAlertMasterViewModel model)
        {
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive==true).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName

            }).ToList();

            return View(model);
        }

        //Get Prealert Data
        public JsonResult GetPreAlert()
        {

            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            IQueryable<PreAlertMaster> data = _ctx.Set<PreAlertMaster>().AsQueryable();
            int totalRecord = 0;
            int filterRecord = 0;

            totalRecord = data.Count();
            string key = "";
            string value = "";

            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive==true).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName

            }).OrderBy(x=>x.UserName).ToList();

            if (!string.IsNullOrEmpty(searchValue))
            {
                string searchstring = "";
                foreach (string search in searchValue.Split('|', StringSplitOptions.RemoveEmptyEntries).ToList())
                {
                    if (search == "WIP" || search == "Data Entry" || search == "Pending" || search == "Received")
                    {
                        searchValue = search;
                    }
                    else
                    {
                        key = search.Split('_')[0];
                        value = search.Split('_')[1];

                        if (key == "Container")
                        {
                            if (value != "")
                                searchstring = searchstring + key + "=" + '"' + value + '"' + " && ";

                        }
                        else if (key == "Eta")
                        {
                            if (value != "")
                                searchstring = searchstring + key + "=" + '"' + Convert.ToDateTime(value) + '"' + " && ";
                        }
                        else if (key == "Status")
                        {
                            if (value != "--select--")
                                searchstring = searchstring + key + ".Contains" + '(' + '"' + value + '"' + ')' + " && ";
                        }
                        else if (key == "Office")
                        {
                            if (value != "--select--")
                                searchstring = searchstring + key + ".Contains" + '(' + '"' + value + '"' + ')' + " && ";
                        }
                    }
                }
                if (searchstring != "")
                {
                    searchstring = searchstring.Trim().Substring(0, searchstring.Length - 3);
                    data = data.Where(searchstring.Trim());
                }
            }
            try
            {
                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    data = data.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            catch { }

            List<PreAlertMasterViewModel> result = new List<PreAlertMasterViewModel>();

            if (searchValue == "Data Entry" || searchValue == "WIP" || searchValue == "Query" || searchValue == "Pending")
            {
                if (searchValue == "eta10")
                {
                    result = data.Where(x => x.Eta.Value.AddDays(-10) <= DateTime.Now && (x.Status == null || x.Status == "WIP")).Select(x => new PreAlertMasterViewModel
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        RecievedDate = x.RecievedDate,
                        UserId = _ctx.Users.Where(y => y.Wnsid == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                        Status = x.Status,
                        Mbl = x.Mbl,
                        ComplitionTime = x.ComplitionTime,
                        Hblcount = x.Hblcount,
                        Pol = x.Pol,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                        FileType = ""
                    }).ToList();
                }
                else
                {
                    result = data.Where(x => x.Status == searchValue).Select(x => new PreAlertMasterViewModel
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        RecievedDate = x.RecievedDate,
                        UserId = _ctx.Users.Where(y => y.Id == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                        Status = x.Status,
                        Mbl = x.Mbl,
                        ComplitionTime = x.ComplitionTime,
                        Hblcount = x.Hblcount,
                        Pol = x.Pol,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                        FileType = ""
                    }).ToList();
                }
            }
            else
            {
                result = data.Skip(skip).Take(pageSize == -1 ? 100 : pageSize).Select(x => new PreAlertMasterViewModel
                {
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    RecievedDate = x.RecievedDate,
                    UserId = _ctx.Users.Where(y => y.Id == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                    Status = x.Status,
                    Mbl=x.Mbl,
                    ComplitionTime = x.ComplitionTime,
                    Hblcount = x.Hblcount,
                    Pol=x.Pol,
                    Pod=x.Pod,
                    Eta = x.Eta,
                    Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                    FileType=""
                }).ToList();
            }
            filterRecord=data.Count();
            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = filterRecord,
                data = result
            };
            return Json(returnObj);
        }

        public IActionResult Insert_PreAlert()
        {
            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).ToList();

            return View();
        }

        //Insert Prealert
        [HttpPost]
        public IActionResult Insert_PreAlert(PreAlertMaster preAlert)
        {
            try
            {
                var found = _ctx.FileMaster.Where(x => x.FileNumber == preAlert.FileNumber).FirstOrDefault();
                var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                string userId = _ctx.Users.Where(x => x.Id == userid).FirstOrDefault().UserName;
                var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();

                string SaveFileFeedback = "";
                string Msg = "";
                var result = _ctx.PreAlertMaster.Where(x => x.Container == preAlert.Container).FirstOrDefault();

                if (result==null)
                {
                    if (preAlert.Container == null || preAlert.RecievedDate == null || preAlert.Status == null)
                    {
                        SaveFileFeedback = "Container or Received Date or Status should not be blank.!";
                    }
                    else
                    {
                        if (result == null)
                        {
                            preAlert.Id = Guid.NewGuid();
                            preAlert.UserId = userid;
                            preAlert.CreatedDate = DateTime.Now;
                            preAlert.ComplitionTime = DateTime.Now;
                            preAlert.Status = "Pending";
                            _ctx.PreAlertMaster.Add(preAlert);
                            _ctx.SaveChanges();
                        }
                        else
                        {
                            SaveFileFeedback = "Container Already present.!";
                        }
                    }
                }
                else
                {
                    FileMaster fmaster;
                    if (result != null)
                    {
                        if (preAlert.Status == "Data Entry")
                        {
                            result.FuserId =wnsid;
                            result.Eta=preAlert.Eta;
                            result.Status=preAlert.Status;
                            result.FileNumber=preAlert.FileNumber;
                            result.Hblcount=preAlert.Hblcount;
                            result.Pol=preAlert.Pol;
                            result.Pod=preAlert.Pod;
                            result.Office=preAlert.Office;
                            result.RecievedDate=preAlert.RecievedDate;
                            result.FileType=preAlert.FileType;

                            _ctx.PreAlertMaster.Update(result);
                            _ctx.SaveChanges();
                            int days = (int)Math.Round((Convert.ToDateTime(result.Eta) - DateTime.Now).TotalDays);
                            if (days < 0)
                            {
                                Msg=Convert.ToDateTime(result.Eta).ToShortDateString() + " Backdated ETA Inserted..Please check..!";
                            }
                            else
                            {
                                fmaster = new FileMaster
                                {
                                    FileNumber = result.FileNumber,
                                    Container = result.Container,
                                    Pod = result.Pod,
                                    Pol = result.Pol,
                                    Mbl = result.Mbl,
                                    Hblcount = result.Hblcount,
                                    Eta = result.Eta,
                                    Office = result.Office,
                                    RecievedDate = result.RecievedDate,
                                    FileType = result.FileType,
                                    ContactPerson = result.ContractPerson,
                                    CreateDateTime = result.CreatedDate,
                                    UserId = result.UserId
                                };
                                var result1 = _ctx.FileMaster.Where(x => x.FileNumber == fmaster.FileNumber).FirstOrDefault();
                                if (result1 == null)
                                {
                                    _ctx.FileMaster.Add(fmaster);
                                    _ctx.SaveChanges();
                                    SaveFileFeedback = "File " + " " + preAlert.FileNumber + " " + " Created successfully.!";
                                    preAlert = new PreAlertMaster() { Eta = DateTime.Now };
                                    // LstPreAlertFileMaster = new ObservableCollection<PreAlertMaster>(_ctx.PreAlertMaster.Where(x => x.Status == "Pending").OrderBy(x => x.RecievedDate).ToList());
                                }
                                else
                                {
                                    Msg=("File already present.!");
                                }
                            }
                        }
                        else
                        {
                            _ctx.PreAlertMaster.Update(result);
                            _ctx.SaveChanges();
                            SaveFileFeedback = "Container " + " " + preAlert.Container + " " + " Updated successfully.!";
                        }
                    }
                    else
                    {
                        result.RecievedDate = preAlert.RecievedDate;
                        result.Container = preAlert.Container;
                        result.Pod = preAlert.Pod;
                        result.Pol = preAlert.Pol;
                        result.Mbl = preAlert.Mbl;
                        result.Hblcount = preAlert.Hblcount;
                        result.Eta = preAlert.Eta;
                        //result.Office = CurrentLocSelection.LocationName;
                        result.ContractPerson = preAlert.ContractPerson;
                        result.MissDocReceivedDate = preAlert.MissDocReceivedDate;
                        //result.AmsCheck = PreAlertMaster.AmsCheck;
                        //result.IfsCheck = PreAlertMaster.IfsCheck;
                        //result.HazDoc = PreAlertMaster.HazDoc;
                        //result.Priority = PreAlertMaster.Priority;
                        result.PieceCount = preAlert.PieceCount;
                        result.Remarks = preAlert.Remarks;
                        //result.ChecklistComplitionDate = PreAlertMaster.ChecklistComplitionDate;
                        result.UserId = userid;
                        result.UpdationTime = DateTime.Now;
                        result.Status = preAlert.Status;
                        _ctx.PreAlertMaster.Update(result);
                        _ctx.SaveChanges();
                        SaveFileFeedback = "Container " + " " + preAlert.Container + " " + " Updated successfully.!";

                    }

                }
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("PreAlert", "Admin", "File Added Successfully!");
        }
        public IActionResult PreAlertEdit(string id)
        {

            id = id.Replace('/', ' ').Trim();
            PreAlertMasterViewModel _PreAlertMasterViewModel = new PreAlertMasterViewModel();
            try
            {
                var result = _ctx.PreAlertMaster.FirstOrDefault(x => x.Container == id);
                _PreAlertMasterViewModel = new PreAlertMasterViewModel()
                {
                    FileNumber = result.FileNumber,
                    Container = result.Container,
                    Hblcount = result.Hblcount,
                    RecievedDate = result.RecievedDate,
                    Office = result.Office,
                    Eta = result.Eta,
                    Status=result.Status,
                    Pol=result.Pol,
                    Pod=result.Pod,
                    ContractPerson=result.ContractPerson,
                    FileType=result.FileType,
                    UserId=result.UserId
                };

                ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
                {
                    Id = x.Id,
                    OfficeName = x.OfficeName

                }).ToList();

            }
            catch (Exception ex)
            {

            }
            return View(_PreAlertMasterViewModel);
        }
        [HttpPost]
        public IActionResult PreAlertUpdate(PreAlertMasterViewModel model)
        {
            try
            {
                var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                string userId = _ctx.Users.Where(x => x.Id == userid).FirstOrDefault().UserName;
                var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();

                PreAlertMaster PAM = _ctx.PreAlertMaster.First(x => x.Container == model.Container);
                PAM.Hblcount = model.Hblcount;
                PAM.Container = model.Container;
                PAM.Eta = model.Eta;
                PAM.RecievedDate = model.RecievedDate;
                PAM.Hblcount = model.Hblcount;
                PAM.Office = model.Office;
                PAM.FuserId = wnsid;
                PAM.Status = model.Status;
                PAM.ContractPerson = model.ContractPerson;

                _ctx.PreAlertMaster.Update(PAM);
                _ctx.SaveChanges();
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("PreAlert", "Admin", "File Added Successfully!");
        }
        public JsonResult GetPreAlertDashboard()
        {
            var result = _ctx.PreAlertMaster.ToList();
            PreAlertDashboard model = new PreAlertDashboard
            {
                Received = result.Count,
                Pending = result.Where(x => x.Status == "Pending").ToList().Count,
                WIP = result.Where(x => x.Status == "WIP").ToList().Count,
                DataEntry = result.Where(x => x.Status == "Data Entry" ||x.Status==null).ToList().Count
            };
            return Json(model);
        }
        //TracknTrace Module
        public IActionResult TracknTrace(TrackNTaceReportModel model)
        {
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive==true).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName

            }).OrderBy(x=>x.UserName).ToList();

            return View(model);
        }
        public JsonResult GetTrackTrace()
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            IQueryable<FileMaster> data = _ctx.Set<FileMaster>().AsQueryable();
            int totalRecord = 0;
            int filterRecord = 0;
            //var draw = Request.Form["draw"].FirstOrDefault();
            totalRecord = data.Count();
            string key = "";
            string value = "";

            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive==true).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName

            }).ToList();

            if (!string.IsNullOrEmpty(searchValue))
            {
                string searchstring = "";
                foreach (string search in searchValue.Split('|', StringSplitOptions.RemoveEmptyEntries).ToList())
                {
                    if (search == "WIP" || search == "Completed" || search == "Pending" || search == "Query" || search == "Received" || search == "eta10" || search == "eta12" ||
                        search == "eta18")
                    {
                        searchValue = search;
                    }
                    else
                    {
                        key = search.Split('_')[0];
                        value = search.Split('_')[1];

                        if (key == "FileNumber")
                        {
                            if (value != "--select--")
                                searchstring = searchstring + key + "=" + '"' + value + '"' + " && ";

                        }
                        else if (key == "Eta")
                        {
                            if (value != "")
                                searchstring = searchstring + key + "=" + '"' + Convert.ToDateTime(value) + '"' + " && ";
                        }
                        else if (key == "Office")
                        {
                            if (value != "--select--")
                                searchstring = searchstring + key + ".Contains" + '(' + '"' + value + '"' + ')' + " && ";
                        }
                    }
                }
                if (searchstring != "")
                {
                    searchstring = searchstring.Trim().Substring(0, searchstring.Length - 3);
                    data = data.Where(searchstring.Trim());
                }
            }
            try
            {
                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    data = data.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            catch { }

            List<TrackNTaceReportModel> result = new List<TrackNTaceReportModel>();

            if (searchValue == "Completed" || searchValue == "WIP" || searchValue == "Query" || searchValue == "Pending" || searchValue == "eta10" || searchValue == "eta12"
                || searchValue == "eta18")
            {
                if (searchValue == "eta10")
                {
                    result = data.Where(x => x.Eta.Value.AddDays(-10) <= DateTime.Now && (x.Hblstatus == null || x.Hblstatus == "WIP")).Select(x => new TrackNTaceReportModel
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        RecievedDate = x.RecievedDate,
                        UserId = _ctx.Users.Where(y => y.Wnsid == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        Mbl = x.Mbl,
                        //ComplitionTime = x.ComplitionTime,
                        Hblcount = x.Hblcount,
                        Pol = x.Pol,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                        FileType = ""
                    }).ToList();
                }
                else
                {
                    result = data.Where(x => x.Hblstatus == searchValue).Select(x => new TrackNTaceReportModel
                    {
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        RecievedDate = x.RecievedDate,
                        UserId = _ctx.Users.Where(y => y.Wnsid == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus = x.Hblstatus,
                        Mbl = x.Mbl,
                        //ComplitionTime = x.ComplitionTime,
                        Hblcount = x.Hblcount,
                        Pol = x.Pol,
                        Pod = x.Pod,
                        Eta = x.Eta,
                        Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                        FileType = ""
                    }).ToList();
                }
            }
            else
            {
                result = data.Skip(skip).Take(pageSize == -1 ? 100 : pageSize).Select(x => new TrackNTaceReportModel
                {
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    RecievedDate = x.RecievedDate,
                    UserId = _ctx.Users.Where(y => y.Id == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                    Hblstatus = x.Hblstatus,
                    Mbl=x.Mbl,
                    FileComplitionDate = x.FileComplitionDate,
                    Hblcount = x.Hblcount,
                    Pol=x.Pol,
                    Pod=x.Pod,
                    Eta = x.Eta,
                    Office = _ctx.OfficeMaster.Where(y => y.OfficeName == x.Office).Select(y => y.OfficeName).First(),
                    FileType="",
                    EtaChangedBy=_ctx.Users.Where(y => y.Wnsid == x.EtaChangedBy).Select(y => y.UserName).FirstOrDefault(),
                    EtaChangedComment=x.EtaChangedComment,
                    EtaChangedDatetime=x.EtaChangedDatetime,
                    CreateDateTime=x.CreateDateTime
                }).Where(x => x.Hblstatus==null).ToList();

            }
            filterRecord=data.Count();
            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = filterRecord,
                data = result
            };

            return Json(returnObj);
        }

        public ActionResult TrackTraceFileEdit(string id)
        {
            id = id.Replace('/', ' ').Trim();
            TrackNTaceReportModel _TrackNTaceReportModel = new TrackNTaceReportModel();
            try
            {
                var result = _ctx.FileMaster.FirstOrDefault(x => x.FileNumber == id);
                _TrackNTaceReportModel = new TrackNTaceReportModel()
                {
                    FileNumber = result.FileNumber,
                    Container = result.Container,
                    Hblcount = result.Hblcount,
                    RecievedDate = result.RecievedDate,
                    Office = result.Office,
                    Eta = result.Eta,
                    Hblstatus=result.Hblstatus,
                    Pol=result.Pol,
                    Pod=result.Pod,
                    FileType=result.FileType,
                    UserId=result.UserId,
                    TrackNtraceUserId=result.UserId
                };

                ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
                {
                    Id = x.Id,
                    OfficeName = x.OfficeName

                }).OrderBy(x=>x.OfficeName).ToList();
            }
            catch (Exception ex)
            {

            }
            return View(_TrackNTaceReportModel);
        }

        [HttpPost]
        public IActionResult TrackTraceUpdate(TrackNTaceReportModel model)
        {
            try
            {
                var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                string userId = _ctx.Users.Where(x => x.Id == userid).FirstOrDefault().UserName;
                var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();



                var file = _ctx.FileMaster.Where(x => x.FileNumber==model.FileNumber).FirstOrDefault();
                file.PreviousEta =file.Eta;
                file.Eta=model.Eta;
                file.EtaChangedBy=wnsid;
                file.EtaChangedDatetime=DateTime.Now;
                file.TrackNtraceUserId=userid;
                file.EtaChangedComment="Eta Changed";
                _ctx.FileMaster.Update(file);
                _ctx.SaveChanges();
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("TracknTrace", "Admin");
        }

        //Report Download
        public ActionResult Report()
        {

            return View();
        }

        [HttpPost]
        public ActionResult Report(ReportViewModel report)
        {
            IQueryable<UserMaster> udata = _ctx.Set<UserMaster>().AsQueryable();
            if (report.start_date!= null || report.end_date != null)
            {
                var Startdate = report.start_date;
                var enddate = report.end_date;
                DataTable dt = new DataTable();
                dt.Columns.Add("File Number");
                dt.Columns.Add("Container No");
                dt.Columns.Add("HBL Count");
                dt.Columns.Add("POD");
                dt.Columns.Add("POL");
                dt.Columns.Add("ETA");
                dt.Columns.Add("Office");
                dt.Columns.Add("File Type");
                dt.Columns.Add("Contact Person");
                dt.Columns.Add("File Creation Date");
                dt.Columns.Add("File Complition Date");
                dt.Columns.Add("File createBy");
                dt.Columns.Add("File CompletedBy");
                dt.Columns.Add("File Complition Status");


                DataTable dt1 = new DataTable();
                dt1.Columns.Add("File Number");
                dt1.Columns.Add("Container Number");
                dt1.Columns.Add("HBL No");
                dt1.Columns.Add("Hbl POD");
                dt1.Columns.Add("Hbl PLD");
                dt1.Columns.Add("Hbl Processing Status");
                dt1.Columns.Add("Hbl Processing Date");
                dt1.Columns.Add("Hbl Processing Comment");
                dt1.Columns.Add("Invoicing Status");
                dt1.Columns.Add("Invoice Processing Date");
                dt1.Columns.Add("Invoice Processing Comment");
                dt1.Columns.Add("AMS Status");
                dt1.Columns.Add("AMS Processing Date");
                dt1.Columns.Add("AMS Processing Comment");
                dt1.Columns.Add("HBL CompletedBy");

                DataTable dt2 = new DataTable();
                dt2.Columns.Add("File Number");
                dt2.Columns.Add("Container#");
                dt2.Columns.Add("Received Date");
                dt2.Columns.Add("Created Date");
                dt2.Columns.Add("Created By");

                DataTable dt3 = new DataTable();
                dt3.Columns.Add("File Number");
                dt3.Columns.Add("Container#");
                dt3.Columns.Add("Eta");
                dt3.Columns.Add("New Eta");
                dt3.Columns.Add("Previous Eta");
                dt3.Columns.Add("Track n Trace User");


                DataTable dt4 = new DataTable();
                dt4.Columns.Add("File Number");
                dt4.Columns.Add("HblNo");
                dt4.Columns.Add("ErrorField");
                dt4.Columns.Add("ErrorType");
                dt4.Columns.Add("Comment");
                dt4.Columns.Add("L1Comment");
                dt4.Columns.Add("QcStatus");
                dt4.Columns.Add("Qcuser");
                dt4.Columns.Add("StartTime");
                dt4.Columns.Add("EndTime");

                DataTable dt5 = new DataTable();
                dt5.Columns.Add("File Number");
                dt5.Columns.Add("Hblcount");
                dt5.Columns.Add("QcStatus");
                dt5.Columns.Add("Qcuser");
                dt5.Columns.Add("Eta");
                dt5.Columns.Add("StartTime");
                dt5.Columns.Add("EndTime");

                DataTable dt6 = new DataTable();
                dt6.Columns.Add("QC Date");
                dt6.Columns.Add("Process Date");
                dt6.Columns.Add("EMP ID");
                dt6.Columns.Add("Name");
                dt6.Columns.Add("File Name");
                dt6.Columns.Add("HBL No");
                dt6.Columns.Add("QC Name");
                dt6.Columns.Add("FieldName");
                dt6.Columns.Add("L1");
                dt6.Columns.Add("L2");
                dt6.Columns.Add("L3");
                dt6.Columns.Add("L4");
                dt6.Columns.Add("Error Type");
                dt6.Columns.Add("Comments");
                dt6.Columns.Add("Office");
                dt6.Columns.Add("POL");
                dt6.Columns.Add("POD");
                dt6.Columns.Add("ICName");

                string us = udata.Where(y => y.Wnsid == "326068").Select(y => y.Doc_Contact).First();

                var result1 = _ctx.FileMaster.Where(x => x.FileComplitionDate >= Convert.ToDateTime(Startdate) && x.FileComplitionDate <= Convert.ToDateTime(enddate)).Select(x => new Models.ReportModel
                {
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    hblcnt = x.Hblcount,
                    pod = x.Pod,
                    pol = x.Pol,
                    Eta = x.Eta,
                    office = x.Office,
                    filetype = x.FileType,
                    contactperson=x.ContactPerson,
                    filecreationdate = x.CreateDateTime,
                    filecomplitiondate = x.FileComplitionDate,                    
                    createdby = udata.Where(y => y.Id == x.UserId).Select(y => y.Doc_Contact.Replace("\r\n", "")).First(),
                    filecomuser = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.Doc_Contact.Replace("\r\n", "")).First(),
                    filecomStatus = x.Hblstatus

                }).ToList();

                var exceptionList = _ctx.FileMaster.Where(x => x.FileComplitionDate >= Convert.ToDateTime(Startdate) && x.FileComplitionDate <= Convert.ToDateTime(enddate)).Select(e => e.FileNumber).ToList();

                IQueryable<FileMaster> fdata = _ctx.Set<FileMaster>().AsQueryable();

                var result = _ctx.Hblmaster.Where(x => exceptionList.Contains(x.FileNumber)).Select(x => new Models.HBLDetailModel
                {
                    FileNumber = x.FileNumber,
                    Container=fdata.Where(z => z.FileNumber==x.FileNumber).Select(z => z.Container).FirstOrDefault(),
                    Hblno = x.Hblno,
                    hblpld = x.Pld,
                    hblprostatus = x.HblprocessingStatus,
                    hblprodate = x.HblprocessingDate,
                    hblprocomment = x.Hblcomments,
                    invoicestatus = x.InvoicingStatus,
                    invoicedate = x.InvoicingDate,
                    invoiceprocomment = x.InvoicingComments,
                    amsstatus = x.Amsstatus,
                    amsdate = x.AmsprocessingDate,
                    amsprocomment = x.Amscomments,
                    HblCompletedBy =udata.Where(y => y.Wnsid == x.UserId).Select(y => y.Doc_Contact.Replace("\r\n", "")).First(),
                }).ToList();

                var result2 = _ctx.FileMaster.Where(x => x.CreateDateTime >= Convert.ToDateTime(Startdate) && x.CreateDateTime <= Convert.ToDateTime(enddate)).Select(x => new FileCreationReportModel
                {
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    FileReceivedDate = x.RecievedDate,
                    filecreationdate = x.CreateDateTime,
                    createdby = udata.Where(y => y.Id == x.UserId).Select(y => y.Doc_Contact.Replace("\r\n", "")).First(),
                }).ToList();

                var result3 = _ctx.FileMaster.Where(x => x.TrackNtraceUserId != null).Select(x => new TrackNTaceReportModel
                {
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    Eta = x.Eta,
                    NewEta = x.NewEta,
                    PreviousEta = x.PreviousEta,
                    UserId = udata.Where(y => y.Id == x.TrackNtraceUserId).Select(y => y.Doc_Contact.Replace("\r\n", "")).First()
                }).ToList();

                var result4 = _ctx.QcMaster.Where(x => x.StartTime >= Convert.ToDateTime(Startdate) && x.StartTime <= Convert.ToDateTime(enddate)).Select(x => new QCReportModel
                {
                    FileNumber = x.FileNumber,
                    HblNo=x.HblNo,
                    ErrorField=x.ErrorField,
                    ErrorType=x.ErrorType,
                    Comment=x.Comment,
                    L1comment=x.L1comment,
                    QcStatus=x.QcStatus,
                    StartTime=x.StartTime,
                    EndTime=x.EndTime,
                    Qcuser =udata.Where(y => y.Wnsid == x.Qcuser).Select(y => y.Doc_Contact.Replace("\r\n","").Trim()).First(),

                }).ToList();

                var result5 = _ctx.FileMaster.Select(x => new ReportQCFileMasterModel
                {
                    FileNumber = x.FileNumber,
                    Hblcount=x.Hblcount,
                    QcStatus=x.QcStatus,
                    Qcuser =udata.Where(y => y.Wnsid == x.Icuser).Select(y => y.Doc_Contact.Replace("\r\n", "")).First(),
                    Eta=x.Eta,
                    StartTime=x.FileStartTime,
                    EndTime=x.FileComplitionDate
                }).ToList();

                var result6 = (from qm in _ctx.QcMaster
                               join fm in _ctx.FileMaster
                               on qm.FileNumber equals fm.FileNumber
                               where (qm.StartTime >= Convert.ToDateTime(Startdate) && qm.StartTime <= Convert.ToDateTime(enddate))
                               select new QCAuditReport
                               {
                                   QCdate=Convert.ToDateTime(qm.StartTime),
                                   Processdate=Convert.ToDateTime(fm.FileComplitionDate),
                                   EMP_ID=fm.Hbluser,
                                   Name=udata.Where(y => y.Wnsid == fm.Hbluser).Select(y => y.Doc_Contact.Replace("\r\n", "")).First(),
                                   FileName=fm.FileNumber,
                                   HBLNo=qm.HblNo,
                                   QCName=udata.Where(y => y.Wnsid == fm.Icuser).Select(y => y.Doc_Contact.Replace("\r\n", "")).First(),
                                   FieldName=qm.ErrorField,
                                   L1=qm.L1comment,
                                   L2=qm.L2comment,
                                   L3=qm.L3comment,
                                   L4=qm.L4comment,
                                   ErrorType=qm.ErrorType,
                                   Comments=qm.Comment,
                                   Office=fm.Office,
                                   POL=fm.Pol,
                                   POD=fm.Pod,
                                   ICName=fm.ContactPerson
                               }).ToList();

                DataTable dtt1 = ToDataTable(result1);
                DataTable dtt = ToDataTable(result);
                DataTable dtt2 = ToDataTable(result2);
                DataTable dtt3 = ToDataTable(result3);
                DataTable dtt4 = ToDataTable(result4);
                DataTable dtt5 = ToDataTable(result5);
                DataTable dtt6 = ToDataTable(result6);

                foreach (DataRow item in dtt1.Rows)
                {
                    DataRow dr = dt.NewRow();
                    for (int i = 0; i < dtt1.Columns.Count; i++)
                    {
                        dr[i] = item[i];
                    }
                    dt.Rows.Add(dr);
                }

                foreach (DataRow item in dtt.Rows)
                {
                    DataRow dr = dt1.NewRow();
                    for (int i = 0; i < dtt.Columns.Count; i++)
                    {
                        dr[i] = item[i];
                    }
                    dt1.Rows.Add(dr);
                }

                foreach (DataRow item in dtt2.Rows)
                {
                    DataRow dr = dt2.NewRow();
                    for (int i = 0; i < dtt2.Columns.Count; i++)
                    {
                        dr[i] = item[i];
                    }
                    dt2.Rows.Add(dr);
                }

                foreach (DataRow item in dtt3.Rows)
                {
                    DataRow dr = dt3.NewRow();
                    for (int i = 0; i < dtt3.Columns.Count; i++)
                    {
                        dr[i] = item[i];
                    }
                    dt3.Rows.Add(dr);
                }

                foreach (DataRow item in dtt4.Rows)
                {
                    DataRow dr = dt4.NewRow();
                    for (int i = 0; i < dtt4.Columns.Count; i++)
                    {
                        dr[i] = item[i];
                    }
                    dt4.Rows.Add(dr);
                }

                foreach (DataRow item in dtt5.Rows)
                {
                    DataRow dr = dt5.NewRow();
                    for (int i = 0; i < dtt5.Columns.Count; i++)
                    {
                        dr[i] = item[i];
                    }
                    dt5.Rows.Add(dr);
                }
                foreach (DataRow item in dtt6.Rows)
                {
                    DataRow dr = dt6.NewRow();
                    for (int i = 0; i < dtt6.Columns.Count; i++)
                    {
                        dr[i] = item[i];
                    }
                    dt6.Rows.Add(dr);
                }

                //saveFile.Filter = "Excel files (*.xlsx)|*.xlsx";
                //saveFile.Filter = "Excel files (*.xlsx)";
                string filename = "";

                //filename = saveFile.FileName;

                string apath = filename + ".xlsx";
                using (XLWorkbook wb = new XLWorkbook())
                {
                    dt.TableName = "File Data";
                    dt1.TableName = "HBL Data";
                    dt2.TableName = "File Creation Data";
                    dt3.TableName = "Track N Trace Data";
                    dt4.TableName = "QcMaster Data";
                    dt5.TableName = "QcFileMaster Data";
                    dt6.TableName = "QCAudit Data";
                    var wsFileData = wb.Worksheets.Add(dt);
                    var wsHblData = wb.Worksheets.Add(dt1);
                    var wsFileCreation = wb.Worksheets.Add(dt2);
                    var wstrackntrace = wb.Worksheets.Add(dt3);
                    var wsQCData = wb.Worksheets.Add(dt4);
                    var fileQC = wb.Worksheets.Add(dt5);
                    var fileQCAudit = wb.Worksheets.Add(dt6);

                    try
                    {
                        using (MemoryStream stream = new MemoryStream())
                        {
                            wb.SaveAs(stream);
                            string excelname = $"UserReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                            return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                        }

                        // System.Windows.Forms.MessageBox.Show("File Save Successfully.!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        // System.Windows.Forms.MessageBox.Show("Something went wrong.!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                // System.Windows.Forms.MessageBox.Show("Please select date range", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return View();
        }
        //List to Database convert
        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }
        //QC Dashboard
        public ActionResult QCDashboard()
        {
            ViewData["Users"] = _ctx.UserMaster.Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName

            }).OrderBy(x=>x.UserName).ToList();

            ViewData["Users"] = (from u in _ctx.UserMaster
                                 join ur in _ctx.UserRoles
                                 on u.Id equals ur.UserId
                                 join r in _ctx.Roles
                                 on ur.RoleId equals r.Id
                                 where (r.Name=="QC" && u.IsActive==true)
                                 select new UserMasterModel
                                 {
                                     Id = u.Id,
                                     UserName = u.UserName
                                 }).OrderBy(x=>x.UserName).ToList();
            return View();
        }

        //Get Next QC 
        [HttpPost]
        public JsonResult GetQC()
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            IQueryable<FileMaster> data = _ctx.Set<FileMaster>().AsQueryable();
            // List<QcMaster> QCdata = _ctx.QcMaster.ToList();
            IQueryable<UserMaster> udata = _ctx.Set<UserMaster>().AsQueryable();

            int totalRecord = 0;
            int filterRecord = 0;

            string key = "";
            string value = "";
            totalRecord=data.Count();

            List<FileMaster> result = new List<FileMaster>();
            if (!string.IsNullOrEmpty(searchValue))
            {
                string searchstring = "";
                foreach (string search in searchValue.Split('|', StringSplitOptions.RemoveEmptyEntries).ToList())
                {
                    if (search == "WIP" || search == "Completed" || search == "Pending" || search == "Query" || search == "Received"|| search == "OnHold" || search == "eta10" || search == "eta12" ||
                        search == "eta18")
                    {
                        searchValue = search;
                    }
                    else
                    {
                        try
                        {
                            key = search.Split('_')[0];
                            value = search.Split('_')[1];
                        }
                        catch (Exception ex)
                        {
                           
                        }   
                        if (key == "FileNumber")
                        {
                            if (value != "--select--")
                                searchstring = searchstring + key + "=" + '"' + value + '"' + " && ";
                        }
                        else if (key == "Eta")
                        {
                            if (value != "")
                                searchstring = searchstring + key + "=" + '"' + Convert.ToDateTime(value) + '"' + " && ";
                        }
                        else if (key == "Office")
                        {
                            if (value != "--select--")
                                searchstring = searchstring + key + ".Contains" + '(' + '"' + value + '"' + ')' + " && ";
                        }
                        else if (key == "Container")
                        {
                            if (value != "--select--")
                                searchstring = searchstring + key + ".Contains" + '(' + '"' + value + '"' + ')' + " && ";
                        }
                        else if (key == "QcStatus")
                        {
                            if (value == "--select--"||value == "--Select--")
                            { }
                            else
                            {
                                searchstring = searchstring + key + "=" + '"' + value + '"' + " && ";
                            }
                        }
                        else if (key == "Pod")
                        {
                            if (value != "--select--")
                                searchstring = searchstring + key + "=" + '"' + value.ToUpper() + '"' + " && ";
                        }
                        else if (key == "Icuser")
                        {
                            if (value == "--select--"||value == "--Select--")
                            { }
                            else
                            {
                                var find = udata.Where(x => x.UserName==value).Select(x => x.Wnsid).FirstOrDefault();
                                searchstring = searchstring + key + "=" + '"' + find + '"' + " && ";
                            }
                        }
                    }
                }
                if (searchstring != "")
                {
                    searchstring = searchstring.Substring(0, searchstring.Length - 3);
                    data = data.Where(searchstring.Trim());
                }
            }
           

            if (searchValue == "Completed" || searchValue== "WIP" || searchValue == "Pending" || searchValue == "eta10" || searchValue == "eta12"
                || searchValue == "eta18"||searchValue=="OnHold"||searchValue=="Received")
            {
                if (searchValue == "eta10")
                {
                    result = data.Where(x => x.Eta.Value.AddDays(-10) <= DateTime.Now && (x.QcStatus == null || x.QcStatus == "Send to Qc")).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container=x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus=x.Hblstatus,
                        FileComplitionDate=x.FileComplitionDate,
                        Hblcount=x.Hblcount,
                        Pod=x.Pod,
                        Eta = x.Eta,
                        QcStatus=x.QcStatus,
                        Icuser =udata.Where(y => y.Wnsid==x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster
                        //Hblmaster = x.Hblmaster,

                    }).ToList();
                }
                else if (searchValue == "eta12")
                {
                    result = data.Where(x => x.Eta.Value.AddDays(-10) > DateTime.Now && x.Eta.Value.AddDays(-12) <= DateTime.Now && (x.QcStatus == null || x.QcStatus == "Send to Qc")).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container=x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus=x.Hblstatus,
                        FileComplitionDate=x.FileComplitionDate,
                        Hblcount=x.Hblcount,
                        Pod=x.Pod,
                        Eta = x.Eta,
                        QcStatus=x.QcStatus,
                        Icuser =udata.Where(y => y.Wnsid==x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster
                        //HblNo = x.QcMaster.Select(x => x.HblNo).FirstOrDefault(),
                        //ErrorField = x.QcMaster.Select(x => x.ErrorField).FirstOrDefault(),
                        //ErrorType = x.QcMaster.Select(x => x.ErrorType).FirstOrDefault(),
                        //QCMasters = x.QcMaster,
                        //Hblmaster = x.Hblmaster
                    }).ToList();
                }
                else if (searchValue == "eta18")
                {
                    result = data.Where(x => x.Eta.Value.AddDays(-12) > DateTime.Now && (x.QcStatus == null || x.QcStatus == "Send to Qc")).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container=x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus=x.Hblstatus,
                        FileComplitionDate=x.FileComplitionDate,
                        Hblcount=x.Hblcount,
                        Pod=x.Pod,
                        Eta = x.Eta,
                        QcStatus=x.QcStatus,
                        Icuser =udata.Where(y => y.Wnsid==x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster
                        //Hblmaster = x.Hblmaster,
                    }).ToList();
                }

                else if (searchValue == "OnHold")
                {
                    result = data.Where(x => (x.QcStatus == "OnHold")).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container=x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus=x.Hblstatus,
                        FileComplitionDate=x.FileComplitionDate,
                        Hblcount=x.Hblcount,
                        Pod=x.Pod,
                        Eta = x.Eta,
                        QcStatus=x.QcStatus,
                        Icuser =udata.Where(y => y.Wnsid==x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster
                        //Hblmaster = x.Hblmaster,
                    }).ToList();
                }
                else if (searchValue == "Received")
                {
                    result = data.Where(x => (x.QcStatus=="Pending"||x.QcStatus=="WIP"||x.QcStatus=="OnHold"||x.QcStatus=="Completed"||x.QcStatus=="Send to Qc"||x.QcStatus=="NotProcessed"||x.QcStatus=="NotInScope")).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container=x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus=x.Hblstatus,
                        FileComplitionDate=x.FileComplitionDate,
                        Hblcount=x.Hblcount,
                        Pod=x.Pod,
                        Eta = x.Eta,
                        QcStatus=x.QcStatus,
                        Icuser =udata.Where(y => y.Wnsid==x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster
                        //Hblmaster = x.Hblmaster,
                    }).ToList();
                }

                else if (searchValue == "Pending")
                {
                    result = data.Where(x => (x.QcStatus=="Pending"||x.QcStatus=="Send to Qc")).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container=x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus=x.Hblstatus,
                        FileComplitionDate=x.FileComplitionDate,
                        Hblcount=x.Hblcount,
                        Pod=x.Pod,
                        Eta = x.Eta,
                        QcStatus=x.QcStatus,
                        Icuser =udata.Where(y => y.Wnsid==x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster
                        //Hblmaster = x.Hblmaster,
                        //QcUser= x.QcUser
                    }).ToList();
                }
                else if (searchValue == "Completed")
                {
                    result = data.Where(x => (x.QcStatus=="Completed"||x.QcStatus=="NotProcessed")).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container=x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus=x.Hblstatus,
                        FileComplitionDate=x.FileComplitionDate,
                        Hblcount=x.Hblcount,
                        Pod=x.Pod,
                        Eta = x.Eta,
                        QcStatus=x.QcStatus,
                        Icuser =udata.Where(y => y.Wnsid==x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster
                        //Hblmaster = x.Hblmaster
                    }).ToList();
                }
                else
                {                   

                    result = data.Where(x => x.QcStatus == searchValue).Select(x => new FileMaster
                    {
                        FileNumber = x.FileNumber,
                        Container=x.Container,
                        UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                        Hblstatus=x.Hblstatus,
                        FileComplitionDate=x.FileComplitionDate,
                        Hblcount=x.Hblcount,
                        Pod=x.Pod,
                        Eta = x.Eta,
                        QcStatus=x.QcStatus,
                        Icuser =udata.Where(y => y.Wnsid==x.Icuser).Select(y => y.UserName).First(),
                        QcMaster = x.QcMaster
                        //Hblmaster = x.Hblmaster
                    }).ToList();
                }
            }
            else
            {               

                result = data.Include(x => x.QcMaster).Select(x => new FileMaster
                {
                    FileNumber = x.FileNumber,
                    Container=x.Container,
                    UserId = udata.Where(y => y.Wnsid == x.Hbluser).Select(y => y.UserName).FirstOrDefault(),
                    Hblstatus=x.Hblstatus,
                    FileComplitionDate=x.FileComplitionDate,
                    Hblcount=x.Hblcount,
                    Pod=x.Pod,
                    Eta = x.Eta,
                    QcStatus=x.QcStatus,
                    Icuser =udata.Where(y => y.Wnsid==x.Icuser).Select(y => y.UserName).First(),
                    QcMaster = x.QcMaster
                    //Hblmaster = x.Hblmaster
                }).Where(x => (x.QcStatus=="Pending"||x.QcStatus=="WIP"||x.QcStatus=="OnHold"||x.QcStatus=="Completed"||x.QcStatus=="Send to Qc"||x.QcStatus=="NotProcessed"||x.QcStatus=="NotInScope")).ToList();


            }

            DateTime endtime = DateTime.Now;
            stopwatch.Stop();

            IQueryable<FileMaster> SortedData = result.AsQueryable();

            try
            {

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
               
            }
            catch { }

            filterRecord=SortedData.Count();//data
            totalRecord=data.Count();//data6
            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = filterRecord,
                data = SortedData.Skip(skip).Take(pageSize == -1 ? 100 : pageSize).ToList()  //result//data6
            };
            //filterRecord=data.Count();
            //var returnObj = new
            //{
            //    draw = draw,
            //    recordsTotal = totalRecord,
            //    recordsFiltered = filterRecord,
            //    data = result
            //};
            TimeSpan elapsedTime = stopwatch.Elapsed;
            return Json(returnObj);
        }
        //Get QCDashboard count
        public JsonResult GetQCDashboardCount()
        {

            var file = _ctx.FileMaster.ToList();
            var Received_count = file.Where(x => (x.QcStatus=="Pending"||x.QcStatus=="WIP"||x.QcStatus=="OnHold"||x.QcStatus=="Completed"||x.QcStatus=="Send to Qc"||x.QcStatus=="NotProcessed"||x.QcStatus=="NotInScope")).ToList();
            var Pending_count = file.Where(x => (x.QcStatus=="Pending"||x.QcStatus=="Send to Qc")).ToList();
            var WIP_count = file.Where(x => x.QcStatus=="WIP").ToList();
            var OnHold_count = file.Where(x => x.QcStatus=="OnHold").ToList();
            var Completed_count = file.Where(x => x.QcStatus=="Completed"||x.QcStatus=="NotProcessed"||x.QcStatus=="NotInScope").ToList();
            var Eta10_count = file.Where(x => x.Eta.Value.AddDays(-10) <= DateTime.Now && (x.QcStatus == null || x.QcStatus == "Send to Qc")).Count();
            var Eta12_count = file.Where(x => x.Eta.Value.AddDays(-10) > DateTime.Now && x.Eta.Value.AddDays(-12) <= DateTime.Now && x.QcStatus == "Send to Qc").Count();
            var eta18 = file.Where(x => x.Eta.Value.AddDays(-12) > DateTime.Now && x.QcStatus == "Send to Qc").Count();


            QcDashboardCount qc = new QcDashboardCount
            {
                Received=Received_count.Count,
                Pending=Pending_count.Count,
                WIP=WIP_count.Count,
                OnHold=OnHold_count.Count,
                Completed=Completed_count.Count,
                ETA10=Eta10_count,
                ETA12=Eta12_count
            };

            return Json(qc);
        }
        //QC File Allocation
        [HttpPost]
        public JsonResult QCFileAllocate([FromBody]FileMasterViewModel model)
        {
            string Msg = "";
            try
            {
                var userid = _ctx.Users.Where(x => x.Id == model.QcUser).Select(x => x.Wnsid).FirstOrDefault();
                var fileno = _ctx.FileMaster.Where(x => x.FileNumber == model.FileNumber).FirstOrDefault();

                if (fileno!=null)
                {
                    fileno.QcStatus = "WIP";
                    fileno.Icuser=userid;
                    _ctx.FileMaster.Update(fileno);
                    Msg="File Allocation sucessfully";
                }
                _ctx.SaveChanges();
            }
            catch (Exception ex)
            {

            }
            return Json(Msg);
        }
        //QC fileDeallocation
        public IActionResult QCfileDeAllocate(string Filenumber)
        {
            try
            {
                var fileno = _ctx.FileMaster.Where(x => x.FileNumber == Filenumber).FirstOrDefault();
                if (fileno != null)
                {
                    fileno.QcStatus="Send to Qc";
                    fileno.Icuser="";
                }
                _ctx.FileMaster.Update(fileno);
                _ctx.SaveChanges();
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("QcDashboard", "Admin");
        }
        //QC Change Status
        [HttpPost]
        public JsonResult QCChangeStatus([FromBody] FileMasterViewModel file)
        {
            string Msg = "";

            if (file!=null)
            {
                var found = _ctx.FileMaster.Include(x => x.QcMaster).Where(x => x.FileNumber == file.FileNumber).FirstOrDefault();

                if (found!=null)
                {
                    if (found.Hblstatus=="Completed")
                    {
                        if (found.QcStatus=="Completed" && file.QcStatus=="Completed")
                        {
                            Msg="Filestatus already completed.";
                        }
                        else
                        {
                            found.QcStatus=file.QcStatus;
                            _ctx.FileMaster.Update(found);
                            _ctx.SaveChanges();
                            Msg="Filestatus Update Sucessfully";
                        }
                    }
                    else
                    {
                        Msg="We can't changes status file status is not completed.";
                    }
                }
            }
            return Json(Msg);
        }
        //Get QC Data
        [HttpPost]
        public JsonResult GetQcdata([FromBody] FileMasterViewModel file)
        {
            var result = _ctx.QcHblWiseData.Where(x => x.FileNumber==file.FileNumber).Select(x => x).ToList();
            return Json(result);
        }

        //Get UserCount
        public ActionResult GetCountofUser()
        {

            return View();
        }

        [HttpPost]
        public JsonResult GetUserDatacount()
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            List<UserMaster> udata = _ctx.UserMaster.ToList();
            List<FileMaster> fdata = _ctx.FileMaster.ToList();
            var result = from c in fdata
                         group c.Hbluser by c.Hbluser into g
                         select new
                         {
                             Username = udata.Where(x => x.Wnsid == g.Key).Select(x => x.Doc_Contact).FirstOrDefault(),
                             Total = fdata.Where(x => x.Hbluser==g.Key).Count(),
                             WIP = fdata.Where(x => x.Hbluser==g.Key && x.Hblstatus =="WIP").Count(),
                             Pending = fdata.Where(x => x.Hbluser==g.Key && (x.Hblstatus =="Pending")).Count(),
                             Completed = fdata.Where(x => x.Hbluser==g.Key && x.Hblstatus =="Completed").Count()
                         };

            try
            {

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    result = result.AsQueryable().OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            catch { }

            int totalRecord = 0;
            int filterRecord = 0;

            var returnObj = new
            {
                data = result.Where(x => x.Username!=null)
            };

            return Json(returnObj);
        }

        [HttpPost]
        public JsonResult GetQCUserDatacount()
        {
           
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            List<UserMaster> udata = _ctx.UserMaster.ToList();
            List<FileMaster> fdata = _ctx.FileMaster.ToList();
            var result = from c in fdata
                         group c.Icuser by c.Icuser into g
                         select new
                         {
                             Username = udata.Where(x => x.Wnsid == g.Key).Select(x => x.Doc_Contact).FirstOrDefault(),
                             Total = fdata.Where(x => x.Icuser==g.Key).Count(),
                             WIP = fdata.Where(x => x.Icuser==g.Key && x.QcStatus =="WIP").Count(),
                             Pending = fdata.Where(x => x.Icuser==g.Key && (x.QcStatus =="Pending"||x.QcStatus =="Send to Qc" || x.QcStatus == "NotProcessed" || x.QcStatus == "NotInScope")).Count(),
                             Completed = fdata.Where(x => x.Icuser==g.Key && x.QcStatus =="Completed").Count()
                         };
            try
            {

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    result = result.AsQueryable().OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            catch { }

            int totalRecord = 0;
            int filterRecord = 0;

            var returnObj = new
            {
                data = result.Where(x => x.Username!=null &&x.Total!=0)
            };

            return Json(returnObj);
        }



        [HttpPost]
        public JsonResult GetUserDatacount1(string start_date, string end_date)
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
           
            List<UserMaster> udata = _ctx.UserMaster.ToList();
            List<FileMaster> fdata = _ctx.FileMaster.Where(x => x.FileComplitionDate>=Convert.ToDateTime(start_date) && x.FileComplitionDate<=Convert.ToDateTime(end_date)).ToList();
            var result = from c in fdata
                         group c.Hbluser by c.Hbluser into g
                         select new
                         {
                             Username = udata.Where(x => x.Wnsid == g.Key).Select(x => x.Doc_Contact).FirstOrDefault(),
                             Total = fdata.Where(x => x.Hbluser == g.Key).Count(),
                             WIP = fdata.Where(x => x.Hbluser == g.Key && x.Hblstatus == "WIP").Count(),
                             Pending = fdata.Where(x => x.Hbluser == g.Key && (x.Hblstatus == "Pending")).Count(),
                             Completed = fdata.Where(x => x.Hbluser == g.Key && x.Hblstatus == "Completed").Count()
                         };

            try
            {

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    result = result.AsQueryable().OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            catch { }

            int totalRecord = 0;
            int filterRecord = 0;

            var returnObj = new
            {
                data = result.Where(x => x.Username != null)
            };

            return Json(returnObj);
        }

        [HttpPost]
        public JsonResult GetQCUserDatacount1(string start_date, string end_date)
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            
            
            List<UserMaster> udata = _ctx.UserMaster.ToList();
            List<QcMaster> fdata = _ctx.QcMaster.Where(x => x.StartTime >= Convert.ToDateTime(start_date) && x.EndTime <= Convert.ToDateTime(end_date)).ToList();
           

            var result = from c in fdata
                         group c.Qcuser by c.Qcuser into g
                         select new
                         {
                             Username = udata.Where(x => x.Wnsid == g.Key).Select(x => x.Doc_Contact).FirstOrDefault(),
                             Total = fdata.Where(x => x.Qcuser == g.Key).Count(),
                             WIP = fdata.Where(x => x.Qcuser == g.Key && x.QcStatus == "WIP").Count(),
                             Pending = fdata.Where(x => x.Qcuser == g.Key && (x.QcStatus == "Pending" || x.QcStatus == "Send to Qc"|| x.QcStatus == "NotProcessed" || x.QcStatus == "NotInScope")).Count(),
                             Completed = fdata.Where(x => x.Qcuser == g.Key && x.QcStatus == "Completed").Count()
                         };

            try
            {

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                    result = result.AsQueryable().OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            catch { }

            int totalRecord = 0;
            int filterRecord = 0;

            var returnObj = new
            {
                data = result.Where(x => x.Username != null && x.Total != 0)
            };

            return Json(returnObj);
        }
    }
}

