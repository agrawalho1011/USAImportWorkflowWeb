﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using USAImportWorkflowWeb.Data;
using USAImportWorkflowWeb.Models;
using Microsoft.AspNetCore.Authorization;

namespace USAImportWorkflowWeb.Controllers
{
    [Authorize]
    public class QCController : Controller
    {
        private readonly UserManager<UserMaster> userManger;
        private readonly SignInManager<UserMaster> signInManager;
        public ApplicationDbContext _ctx;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public QCController(UserManager<UserMaster> userManger, IHttpContextAccessor httpContextAccessor, SignInManager<UserMaster> signInManager, ApplicationDbContext ctx)
        {
            this.userManger = userManger;
            this.signInManager = signInManager;
            _httpContextAccessor = httpContextAccessor;
            this._ctx = ctx;
        }


        //Get Next file for QC or Exiting assign
        public IActionResult QC_Home(string Next)
        {
            QCMultiModule qcmodel = new QCMultiModule();
            try
            {
                string Msg = "";
                
                if (Next != null)
                {
                    var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                    var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
                    var allocate = _ctx.FileMaster.Where(x => x.QcStatus == "WIP" && x.Icuser==wnsid).OrderBy(x => x.Eta).FirstOrDefault();

                    if (allocate != null)
                    {
                        var hbls = _ctx.Hblmaster.Where(x => x.FileNumber==allocate.FileNumber).ToList();
                        qcmodel.fileViewModel = new FileViewModule
                        {
                            FileNumber = allocate.FileNumber,
                            Container = allocate.Container,
                            Mbl = allocate.Mbl,
                            Hblcount = allocate.Hblcount,
                            Pol = allocate.Pol,
                            Pod = allocate.Pod,
                            Eta = allocate.Eta,
                            FileType = allocate.FileType,
                            Hblstatus = allocate.Hblstatus                           

                        };

                        foreach (Hblmaster q in hbls)
                        {
                            qcmodel.qcMasterModel.Add(new QCMasterModule
                            {
                                FileNumber = q.FileNumber,
                                Hblno = q.Hblno,

                            });
                        }
                    }
                    else
                    {
                        var location = _ctx.UserOfficeRelation.Where(x => x.UserId == userid).OrderBy(x => x.Order).ToList();

                        var officename = _ctx.OfficeMaster.Where(x => x.Id == location.First().OfficeId).Select(x => x.OfficeName).SingleOrDefault();

                        //var officename_2 = _ctx.OfficeMaster.Where(x => x.Id == location[1].OfficeId).Select(x => x.OfficeName).SingleOrDefault();

                        var file_primary = _ctx.FileMaster.OrderBy(x => x.Eta).Where(x => x.QcStatus == "Send to Qc" && x.Eta != null && x.Office == officename).FirstOrDefault();
                        //var file_secondary = _ctx.FileMaster.OrderBy(x => x.Eta).Where(x => x.QcStatus == "Send to Qc" && x.Eta != null && x.Office == officename_2).FirstOrDefault();
                        FileMaster file = new FileMaster();
                        
                        if (file_primary != null)
                        {
                            file = _ctx.FileMaster.Include(x => x.Hblmaster).Where(x => x.QcStatus == "Send to Qc" && x.Eta != null && x.Office == officename).OrderBy(x => x.Eta).FirstOrDefault();
                        }
                        else
                        {

                            file = _ctx.FileMaster.Include(x => x.Hblmaster).Where(x => x.QcStatus == "Send to Qc").OrderBy(x => x.Eta).FirstOrDefault();
                        }

                        if (file != null)
                        {
                            file.QcStatus = "WIP";
                            file.Icuser=wnsid;                            
                            _ctx.FileMaster.Update(file);
                            _ctx.SaveChanges();
                            qcmodel.fileViewModel = new FileViewModule
                            {
                                FileNumber = file.FileNumber,
                                Container = file.Container,
                                Mbl = file.Mbl,
                                Hblcount = file.Hblcount,
                                Pol = file.Pol,
                                Pod = file.Pod,
                                Eta = file.Eta,
                                FileType = file.FileType,
                                Hblstatus = file.Hblstatus
                            };

                            List<Hblmaster> hbl = _ctx.Hblmaster.Where(x => x.FileNumber==file.FileNumber).ToList();
                            if (hbl.Count>0)
                            {
                                foreach (Hblmaster q in hbl)
                                {
                                    qcmodel.qcMasterModel.Add(new QCMasterModule
                                    {
                                        FileNumber = q.FileNumber,
                                        Hblno = q.Hblno,

                                    });
                                }
                            }
                            else
                            {
                                Msg="HBL are not available";
                            }
                        }
                        else
                        {
                            Msg = ("No Data for Qc");
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }

            return View(qcmodel);
        }

        public FileMaster QCfilemaster(FileMaster file)
        {

            return file;
        }

        //QC Satus update
        [HttpPost]
        public JsonResult QC_Home([FromBody] FileViewModel qc)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
            string Msg = "";

            //var data = _ctx.QcMaster.ToList();
            //var exceldata = _ctx.QcMaster.Where(x => x.FileNumber == data.Select(y => y.FileNumber).FirstOrDefault()).FirstOrDefault();
            FileMaster fl = _ctx.FileMaster.Where(x => x.FileNumber==qc.FileNumber).Select(x => x).FirstOrDefault();
            if (fl != null)
            {
                fl.Icuser=wnsid;
                fl.QcStatus=qc.QcStatus;
                _ctx.FileMaster.Update(fl);   
                
                Msg = "Qc Done";
                _ctx.SaveChanges();
            }

            return Json(Msg);
        }
        public FileHBLMultiModule groupAllocation(FileMaster files)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
            FileHBLMultiModule fhVM = new FileHBLMultiModule();

            files.Hbluser = wnsid;
            files.Hblstatus = "WIP";
            files.FileStartTime = DateTime.Now;
            _ctx.FileMaster.Update(files);
            _ctx.SaveChanges();

            files = _ctx.FileMaster.Include(p => p.Hblmaster)
           .ThenInclude(c => c.Hblprocessing)
           .Where(x => x.Hbluser == files.Hbluser && x.Hblstatus == "WIP").ToList().FirstOrDefault();
            var hblcount = _ctx.Hblmaster.Where(x => x.FileNumber == files.FileNumber && x.UserId == files.Hbluser).ToList();

            if (hblcount.Count == 0)
            {
                if (files.Hblmaster.Count == 0)
                {
                    for (int j = 0; j < files.Hblcount; j++)
                    {
                        //files.Hblmaster.Add(new Hblmaster());
                        fhVM.hBLMasterViewActionModels.Add(new HBLMasterViewActionModel());
                    }
                }
            }
            if (fhVM.fileViewActionModel.FileNumber == null)
            {
                fhVM.fileViewActionModel = new FileViewActionModel
                {
                    FileNumber = files.FileNumber,
                    Container = files.Container,
                    Mbl = files.Mbl,
                    Eta = files.Eta,
                    Pol = files.Pol,
                    Pod = files.Pol,
                    Hblcount = files.Hblcount,
                    FileType = files.FileType,
                    Hblstatus = files.Hblstatus,
                    Office = files.Office,
                    UserId = wnsid,

                };
            }
            return fhVM;
        }

        //Save File QC Error Add and Update
        [HttpPost]
        public JsonResult Save_Error([FromBody] QcHblWiseData ErrorData)
        {
            string Msg = "";
            try
            {               
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();   
                
                    var qcmasteravailable = _ctx.QcMaster.Where(x => x.ErrorField == ErrorData.ErrorField &&x.ErrorType==ErrorData.ErrorType && x.HblNo==ErrorData.Hblno && x.FileNumber==ErrorData.FileNumber).Select(x=>x.ErrorField).FirstOrDefault();
                    if (qcmasteravailable == null)
                    {  
                        _ctx.QcMaster.Add(new QcMaster
                        {
                            StartTime=DateTime.Now,
                            FileNumber = ErrorData.FileNumber,
                            HblNo = ErrorData.Hblno,
                            ErrorField = ErrorData.ErrorField,
                            ErrorType = ErrorData.ErrorType,
                            Comment = ErrorData.Comment,
                            L1comment = ErrorData.L1comment,
                            L2comment = ErrorData.L2comment,
                            L3comment = ErrorData.L3comment,
                            L4comment = ErrorData.L4comment,
                            Qcuser=wnsid,
                            QcStatus="Completed",
                            EndTime=DateTime.Now

                        }) ;
                        _ctx.SaveChanges();
                        Msg = "Error field is added";
                    }
                    else
                    {
                        QcMaster qc = _ctx.QcMaster.Where(x => x.HblNo==ErrorData.Hblno && x.ErrorField==ErrorData.ErrorField).FirstOrDefault();
                        qc.FileNumber = ErrorData.FileNumber;
                        qc.HblNo = ErrorData.Hblno;
                        qc.ErrorField = ErrorData.ErrorField;
                        qc.ErrorType = ErrorData.ErrorType;
                        qc.Comment = ErrorData.Comment;
                        qc.Qcuser=wnsid;
                        qc.QcStatus="Completed";
                        _ctx.QcMaster.Update(qc);
                        _ctx.SaveChanges();

                        Msg = "Error field is already added";
                    }
                
            }
            catch (Exception ex)
            {
                
            }

            return Json(Msg);
        }
        //Get QC Master Data
        [HttpPost]
        public JsonResult GetQcHblWisedata(string hblno)
        {          
            var qchblwisedata = _ctx.QcMaster.Where(x => x.HblNo==hblno).ToList();           
            int totalRecord = 0;
            int filterRecord = 0;
            
            var returnObj = new
            {               
                data = qchblwisedata
            };
            return Json(returnObj);
        }
    }
}
