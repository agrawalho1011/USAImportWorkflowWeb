﻿
 --FileMaster



Insert Into USAImportWorkflowWeb.dbo.FileMaster
select f.FileNumber,f.Container,f.MBL,f.HBLCount,f.POL,
		f.POD,f.UnitDispo,f.DepFile,f.ShippingLine,f.CFS,f.Vessel,f.Terminal,f.SSLRemarks,f.NewETA,f.DischargeDate,
		f.BerthingDate,f.trackNTraceUserId,f.RecievedDate,f.ETA,f.PreviousETA,f.Office,f.FileType,f.ContactPerson,
		UserID=(select Id from USAImportWorkflowWeb.dbo.[User] Where Wnsid=f.UserId),f.CreateDateTime,
		f.HBLUser,f.HBLStatus,f.DigiviewUser,f.DigiviewStatus,f.ICUser,f.ICStatus,f.Aging,
		f.FileStartTime,f.FileComplitionDate,f.EtaChangedBy,f.EtaChangedComment,f.EtaChangedDatetime,f.QcStatus
	 from USAImportWorkflow.dbo.FileMaster as f
--HBLMaster
Insert Into USAImportWorkflowWeb.dbo.HBLMaster
Select h.HBLNo,h.POD,h.PLD,h.FileNumber,h.UserId,
       h.CreateDate,
	   h.HBLProcessingStatus,h.HBLProcessingDate,h.HBLComments,
	   h.AMSStatus,h.AMSProcessingDate,h.AMSCOmments,
	   h.InvoicingStatus,h.InvoicingDate,h.InvoicingComments,
	   h.DigiviewUser,h.DigiviewStatus,h.DigiviewComments,h.FileNumber from  USAImportWorkflow.dbo.HBLMaster as h
--QcMaster
Insert Into USAImportWorkflowWeb.dbo.QcMaster
select q.Id,q.FileNumber,q.HblNo,q.ErrorField,q.ErrorType
	    ,q.Comment,q.L1Comment,q.L2Comment,q.L3Comment,q.L4Comment,
		q.QcStatus,q.QCUser,q.StartTime,q.EndTime from USAImportWorkflow.dbo.QcMaster as q
--QcHblWiseData
Insert Into USAImportWorkflowWeb.dbo.QcHblWiseData
select q.Id,q.QcMasterId, q.FileNumber,q.HblNo,q.ErrorField,q.ErrorType
	    ,q.Comment,q.L1Comment,q.L2Comment,q.L3Comment,q.L4Comment,
		q.QcStatus,q.QCUser,q.StartTime,q.EndTime from USAImportWorkflow.dbo.QcHblWiseData as q

--PreAlertMaster
Insert Into USAImportWorkflowWeb.dbo.PreAlertMaster
select f.Id,f.FileNumber,f.Container,f.MBL,f.HBLCount,f.POD,
		f.POL,f.RecievedDate,f.ETA,f.Office,f.FileType,f.ContractPerson, UserID=(select Id from USAImportWorkflowWeb.dbo.[User] Where Wnsid=f.UserId),
		f.FUserId,f.CreatedDate,f.ComplitionTime,f.UpdationTime,f.[Status],f.Missing_Doc,
		f.Email_Send_Date,f.Miss_doc_received_date,f.AMS_Check,f.IFS_Check,f.Haz_Doc,f.Piece_Count,f.[Priority],
		f.Remarks,f.checklist_complition_date		
	 from USAImportWorkflow.dbo.PreAlertMaster as f


--OfficeMaster
Insert Into USAImportWorkflowWeb.dbo.OfficeMaster
select *
from USAImportWorkflow.dbo.OfficeMaster as r

--Role
Insert Into USAImportWorkflowWeb.dbo.[Role]
select r.RoleId,r.[Role]
from USAImportWorkflow.dbo.[Role] as r

--UserOfficeRelation

Insert Into USAImportWorkflowWeb.dbo.[UserOfficeRelation]
select s.Id,s.UserId,OfficeId=(select Id from OfficeMaster where OfficeName=s.LocationName),
  s.[Order],'true'
from USAImportWorkflow.dbo.[UserLocationMaster] as s

--UserRole
Insert Into USAImportWorkflowWeb.dbo.[UserRoles]
select UserID=(select Id from USAImportWorkflowWeb.dbo.[User] Where Wnsid=rr.UserId), rr.RoleId
from USAImportWorkflow.dbo.[RoleRelation] as rr









