using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace USAImportWorkflowWeb.Views.Admin
{
    public class EditPartialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
