﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Models
{
    public class AdminDashboardModel
    {
        public int Received { get; set; }
        public int WIP { get; set; }
        public int Completed { get; set; }
        public int Pending { get; set; }
        public int UnAllocated { get; set; }
        public int Query { get; set; }
        public int eta10 { get; set; }
        public int eta12 { get; set; }
        public int eta18 { get; set; }
    }
}
