﻿using System;

namespace USAImportWorkflowWeb.Models
{
    public class ReportModel
    {
        public string FileNumber { get; set; }
        public string Container { get; set; }
        public int? hblcnt { get; set; }
        public string pod { get; set; }
        public string pol { get; set; }
        public DateTime? Eta { get; set; }
        public string office { get; set; }
        public string filetype { get; set; }
        public string contactperson { get; set; }
        public DateTime? filecreationdate { get; set; }
        public string? fileCreationDateIST { get; set; }
        public DateTime? fileProcessingDate { get; set; }
        public string? fileProcessingDateIST { get; set; }
        public DateTime? filecomplitiondate { get; set; }

        public string? fileCompletionDateIST { get; set; }
        public string createdby { get; set; }
        public string filecomuser { get; set; }
        public string filecomStatus { get; set; }
        public string productionDate { get; set; }
    }
}
