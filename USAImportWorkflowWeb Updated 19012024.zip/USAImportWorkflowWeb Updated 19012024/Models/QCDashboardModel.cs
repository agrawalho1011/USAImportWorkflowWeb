﻿using System;

namespace USAImportWorkflowWeb.Models
{
    public class QCDashboardModel
    {
        public string Filenumber { get; set; }
        public string QCStatus { get; set; }
        public string QCUser { get; set; }
        public DateTime Eta { get; set; }
    }
}
