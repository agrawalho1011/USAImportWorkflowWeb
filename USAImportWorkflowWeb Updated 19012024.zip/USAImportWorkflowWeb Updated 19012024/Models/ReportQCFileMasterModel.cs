﻿using System;

namespace USAImportWorkflowWeb.Models
{
    public class ReportQCFileMasterModel
    {
        public string FileNumber { get; set; }  
        public int? Hblcount { get; set; }
        public string? QcStatus { get; set; }
        public string? Qcuser { get; set; }        
        public DateTime? Eta { get; set; }
        //public DateTime? StartTime { get; set; }
        //public DateTime? EndTime { get; set; }
        public DateTime? FileComplitionDate { get; set; }
        public string? FileCompletionDateIST { get; set; }
        public string? ProductionDate { get; set; }
        

    }
}
