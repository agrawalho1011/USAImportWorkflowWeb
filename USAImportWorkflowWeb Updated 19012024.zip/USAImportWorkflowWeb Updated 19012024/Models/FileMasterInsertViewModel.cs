﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Models
{
    public class FileMasterInsertViewModel
    {
        public DateTime? RecievedDate { get; set; }
        [Required]
        public string FileNumber { get; set; }
        [Required]
        public string Container { get; set; }       
        public int? Hblcount { get; set; }
        public DateTime? Eta { get; set; }
        public string OfficeId { get; set; }
        public string Pod { get; set; }
        public string Pol { get; set; }
        public string ContactPerson { get; set; }
        public string FileType { get; set; }

    }
}
