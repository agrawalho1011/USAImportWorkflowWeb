﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using USAImportWorkflowWeb.Data;

namespace USAImportWorkflowWeb.Models
{
    public class FileMasterViewModel
    {
        //public FileMasterViewModel()
        //{
        //    QCMasters = new HashSet<QcMaster>();
        //    Hblmaster = new HashSet<Hblmaster>();
        //}
        [Required]
        public string FileNumber { get; set; }
        [Required]
        public string Container { get; set; }
        public DateTime? RecievedDate { get; set; } 
        public string UserId { get; set; }
        public string Hblstatus { get; set; }
        public int? Hblcount { get; set; } 
        public DateTime? Eta { get; set; }
        public string Office { get; set; }  
        public DateTime? FileComplitionDate { get; set; }
        public DateTime? PreviousEta { get; set; }
        public string EtaChangedBy { get; set; } 
        public DateTime? CreateDateTime { get; set; }
        public string EtaChangedComment { get; set; }
        public DateTime? EtaChangedDatetime { get; set; }
        public string Mbl { get; set; }
        public string Pol { get; set; }
        public string Pod { get; set; }
        public string FileType { get; set; }
        public string QcStatus { get; set; }
        public string QcUser { get; set; }
        public virtual ICollection<Hblmaster> Hblmaster { get; set; }
        public virtual ICollection<QcMaster> QCMasters { get; set; }
        public virtual ICollection<QcHblWiseData> QcHblWiseData { get; set; }

    }
}
