﻿namespace USAImportWorkflowWeb.Models
{
    public class PreAlertDashboard
    {
        public int Received { get; set; }
        public int UnAllocated { get; set; }
        public int DataEntry { get; set; }
        public int Pending { get; set; }
        public int Missing { get; set; }

    }
}
