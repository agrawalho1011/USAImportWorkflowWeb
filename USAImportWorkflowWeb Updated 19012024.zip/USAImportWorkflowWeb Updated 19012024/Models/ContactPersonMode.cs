﻿namespace USAImportWorkflowWeb.Models
{
    public class ContactPersonModel
    {
        public string Name { get; set; }
        public string  Code  { get; set; }
    }
}
