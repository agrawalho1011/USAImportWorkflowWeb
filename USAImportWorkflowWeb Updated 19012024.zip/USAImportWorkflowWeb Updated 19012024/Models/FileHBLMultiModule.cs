﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Models
{
    public class FileHBLMultiModule
    {
        public List<HBLMasterViewActionModel> hBLMasterViewActionModels { get; set; }

        public FileViewActionModel fileViewActionModel { get; set; }
        public FileHBLMultiModule()
        {
            hBLMasterViewActionModels = new List<HBLMasterViewActionModel>();
            fileViewActionModel = new FileViewActionModel();
        }
       
    }
    public class FileViewActionModel
    {
        [Required]
        public string FileNumber { get; set; }
      
        public string Container { get; set; }
        public string UserId { get; set; }
        public string Hblstatus { get; set; }
        public int? Hblcount { get; set; }
        public DateTime? Eta { get; set; }
        public string Office { get; set; }
        public string Mbl { get; set; }
        public string Pol { get; set; }
        public string Pod { get; set; }
        public string FileType { get; set; }
        public string Hbluser { get; set; }       
        public string DigiviewUser { get; set; }
        public string DigiviewStatus { get; set; }
        public string Icuser { get; set; }
        public string Icstatus { get; set; }
        public string Aging { get; set; }
        public DateTime? FileStartTime { get; set; }
        public DateTime? FileComplitionDate { get; set; }
        public string EtaChangedBy { get; set; } = string.Empty;
        public string EtaChangedComment { get; set; } = string.Empty;
        public DateTime? EtaChangedDatetime { get; set; }
    }

    public class HBLMasterViewActionModel
    {
        public string Hblno { get; set; }
        public string Pod { get; set; }
        public string Pld { get; set; }
        public string FileNumber { get; set; }
        public string UserId { get; set; }
        public DateTime? CreateDate { get; set; }
        public string HblprocessingStatus { get; set; }
        public DateTime? HblprocessingDate { get; set; }
        public string Hblcomments { get; set; } = String.Empty;
        public string Amsstatus { get; set; }
        public DateTime? AmsprocessingDate { get; set; }
        public string Amscomments { get; set; } = String.Empty;

        public string InvoicingStatus { get; set; }
        public string InvoicingDate { get; set; }
        public string InvoicingComments { get; set; } = String.Empty;
        public string DigiviewUser { get; set; }
        public string DigiviewStatus { get; set; }
        public string DigiviewComments { get; set; }
    }
}
