﻿using System;

namespace USAImportWorkflowWeb.Models
{
    public class FileCreationReportModel
    {
        public string FileNumber { get; set; }
        public string Container { get; set; }
        public DateTime? FileReceivedDate { get; set; }
        public string? FileReceivedDateIST { get; set; }
        public DateTime? filecreationdate { get; set; }
        public string? fileCreationDateIST { get; set; }
        public string createdby { get; set; }
        public string ProductionDate { get; set; }
    }
}
