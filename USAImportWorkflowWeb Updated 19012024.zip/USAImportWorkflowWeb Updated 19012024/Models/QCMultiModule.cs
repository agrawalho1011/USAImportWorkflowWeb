﻿using System;
using System.Collections.Generic;


namespace USAImportWorkflowWeb.Models
{

    public class QCMultiModule
    {
        public List<QCMasterModule> qcMasterModel { get; set; }

        public FileViewModule fileViewModel { get; set; }
        public QCMultiModule()
        {
            qcMasterModel = new List<QCMasterModule>();
            fileViewModel = new FileViewModule();
        }

    }
    public class QCMasterModule
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid? QcMasterId { get; set; }
        public string FileNumber { get; set; }
        public string Hblno { get; set; }
        public string ErrorField { get; set; }
        public string ErrorType { get; set; }
        public string Comment { get; set; }
        public string L1comment { get; set; }
        public string L2comment { get; set; }
        public string L3comment { get; set; }
        public string L4comment { get; set; }
        public string QcStatus { get; set; }
        public string Qcuser { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        
    }

    public class FileViewModule
    {

        public string FileNumber { get; set; }
        public string Container { get; set; }
        public string UserId { get; set; }
        public string Hblstatus { get; set; }
        public int? Hblcount { get; set; }
        public DateTime? Eta { get; set; }
        public string Office { get; set; }
        public string Mbl { get; set; }
        public string Pol { get; set; }
        public string Pod { get; set; }
        public string FileType { get; set; }

    }


}
