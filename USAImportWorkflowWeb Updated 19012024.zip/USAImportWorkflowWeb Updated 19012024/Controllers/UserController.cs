﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using USAImportWorkflowWeb.Data;
using USAImportWorkflowWeb.Models;

namespace USAImportWorkflowWeb.Controllersl
{
    [Authorize(Roles = "User,QC")]
    public class UserController : Controller
    {
        private readonly UserManager<UserMaster> userManger;
        private readonly SignInManager<UserMaster> signInManager;
        public ApplicationDbContext _ctx;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public UserController(UserManager<UserMaster> userManger, IHttpContextAccessor httpContextAccessor, SignInManager<UserMaster> signInManager, ApplicationDbContext ctx)
        {
            this.userManger = userManger;
            this.signInManager = signInManager;
            _httpContextAccessor = httpContextAccessor;
            this._ctx = ctx;
        }
        [HttpGet]
        public IActionResult Dashboard(string file)
        {

            FileHBLMultiModule fhVM = new FileHBLMultiModule();
            if (file == null)
            {

            }
            else
            {
                var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

                var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
                FileMaster files = _ctx.FileMaster.Include(p => p.Hblmaster)
                .ThenInclude(c => c.Hblprocessing)
                .Where(x => x.Hbluser == wnsid && x.Hblstatus == "WIP").ToList().FirstOrDefault();

                if (files == null)
                {
                    var location = _ctx.UserOfficeRelation.Where(x => x.UserId == userid).OrderBy(x => x.Order).ToList();

                    var officename = _ctx.OfficeMaster.Where(x => x.Id == location.First().OfficeId).Select(x => x.OfficeName).SingleOrDefault();

                    var officename_2 = _ctx.OfficeMaster.Where(x => x.Id == location[1].OfficeId).Select(x => x.OfficeName).SingleOrDefault();

                    var file_primary = _ctx.FileMaster.OrderBy(x => x.Eta).Where(x => x.Hbluser == null && x.Eta != null && x.Office == officename).FirstOrDefault();

                    var file_secondary = _ctx.FileMaster.OrderBy(x => x.Eta).Where(x => x.Hbluser == null && x.Eta != null && x.Office == officename_2).FirstOrDefault();


                    var filetoAllocate = _ctx.FileMaster.Where(x => x.Hbluser == null && (x.Office == officename || x.Office == officename)).OrderBy(x => x.Eta);

                    if (file_primary != null && file_secondary != null)
                    {
                        if (officename.ToString().Trim() == "CHI")
                        {
                            fhVM = groupAllocation(file_primary);
                        }
                        else if(officename_2.ToString().Trim() == "CHI")
                        {
                            fhVM = groupAllocation(file_secondary);
                        }
                        else if (file_primary.Eta <= file_secondary.Eta)
                        {
                            fhVM = groupAllocation(file_primary);
                        }
                        else
                        {
                            fhVM = groupAllocation(file_secondary);
                        }

                    }
                    else if (file_primary != null && file_secondary == null)
                    {

                        fhVM = groupAllocation(file_primary);

                        //Allocate primary
                    }
                    else if (file_primary == null && file_secondary != null)
                    {
                        fhVM = groupAllocation(file_secondary);
                        //Allocate Secondary
                    }
                    else
                    {
                        files = _ctx.FileMaster.Include(p => p.Hblmaster)
                        .Where(x => x.Hbluser == null && x.Eta != null && x.Office != null).OrderBy(x => x.Eta).ToList().FirstOrDefault();

                        if (files != null)
                        {
                            files.Hbluser = wnsid;
                            files.Hblstatus = "WIP";
                            _ctx.FileMaster.Update(files);
                            _ctx.SaveChanges();

                            if (files.Hblmaster.Count == 0)
                            {
                                for (int j = 0; j < files.Hblcount; j++)
                                {
                                    fhVM.hBLMasterViewActionModels.Add(new HBLMasterViewActionModel());
                                }
                            }
                        }
                        else
                        {
                            //System.Windows.Forms.MessageBox.Show("No Data to Allocate");
                        }

                    }
                }
                else
                {
                    var hblcount = _ctx.Hblmaster.Where(x => x.FileNumber == files.FileNumber).ToList();
                    if (hblcount.Count == 0)
                    {
                        for (int j = 0; j < files.Hblcount; j++)
                        {

                            fhVM.hBLMasterViewActionModels.Add(new HBLMasterViewActionModel());
                        }

                        if (fhVM.fileViewActionModel.FileNumber == null)
                        {
                            fhVM.fileViewActionModel = new FileViewActionModel
                            {
                                FileNumber = files.FileNumber,
                                Container = files.Container,
                                Mbl = files.Mbl,
                                Eta = files.Eta,
                                Pol = files.Pol,
                                Pod = files.Pol,
                                Hblcount = files.Hblcount,
                                FileType = files.FileType,
                                Hblstatus = files.Hblstatus,
                                Office = files.Office,
                                UserId = wnsid,

                            };
                        }
                    }
                    else
                    {

                        if (fhVM.fileViewActionModel.FileNumber == null)
                        {
                            fhVM.fileViewActionModel = new FileViewActionModel
                            {
                                FileNumber = files.FileNumber,
                                Container = files.Container,
                                Mbl = files.Mbl,
                                Eta = files.Eta,
                                Pol = files.Pol,
                                Pod = files.Pol,
                                Hblcount = files.Hblcount,
                                FileType = files.FileType,
                                Hblstatus = files.Hblstatus,
                                Office = files.Office,
                                UserId = wnsid,

                            };
                        }

                        for (int j = 0; j < files.Hblcount; j++)
                        {
                            if (j < hblcount.Count)
                            {
                                fhVM.hBLMasterViewActionModels.Add(new HBLMasterViewActionModel
                                {
                                    Hblno = hblcount[j].Hblno,
                                    Pod = hblcount[j].Pod,
                                    Pld = hblcount[j].Pld,
                                    FileNumber = hblcount[j].FileNumber,
                                    UserId = hblcount[j].UserId,
                                    CreateDate = hblcount[j].CreateDate,

                                    HblprocessingStatus = hblcount[j].HblprocessingStatus,
                                    HblprocessingDate = hblcount[j].HblprocessingDate,
                                    Hblcomments = hblcount[j].Hblcomments,
                                    Amsstatus = hblcount[j].Amsstatus,
                                    AmsprocessingDate = hblcount[j].AmsprocessingDate,
                                    Amscomments = hblcount[j].Amscomments,
                                    InvoicingStatus = hblcount[j].InvoicingStatus,
                                    InvoicingDate = hblcount[j].InvoicingDate,
                                    InvoicingComments = hblcount[j].InvoicingComments

                                });
                            }
                            else
                            {
                                fhVM.hBLMasterViewActionModels.Add(new HBLMasterViewActionModel());

                            }
                        }
                    }

                }

            }
            return View(fhVM);
        }

        public FileHBLMultiModule groupAllocation(FileMaster files)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
            FileHBLMultiModule fhVM = new FileHBLMultiModule();

            files.Hbluser = wnsid;
            files.Hblstatus = "WIP";
            files.FileStartTime = DateTime.Now;
            _ctx.FileMaster.Update(files);
            _ctx.SaveChanges();

            files = _ctx.FileMaster.Include(p => p.Hblmaster)
           .ThenInclude(c => c.Hblprocessing)
           .Where(x => x.Hbluser == files.Hbluser && x.Hblstatus == "WIP").ToList().FirstOrDefault();
            var hblcount = _ctx.Hblmaster.Where(x => x.FileNumber == files.FileNumber && x.UserId == files.Hbluser).ToList();

            if (hblcount.Count == 0)
            {
                if (files.Hblmaster.Count == 0)
                {
                    for (int j = 0; j < files.Hblcount; j++)
                    {

                        fhVM.hBLMasterViewActionModels.Add(new HBLMasterViewActionModel());
                    }
                }
            }
            if (fhVM.fileViewActionModel.FileNumber == null)
            {
                fhVM.fileViewActionModel = new FileViewActionModel
                {
                    FileNumber = files.FileNumber,
                    Container = files.Container,
                    Mbl = files.Mbl,
                    Eta = files.Eta,
                    Pol = files.Pol,
                    Pod = files.Pol,
                    Hblcount = files.Hblcount,
                    FileType = files.FileType,
                    Hblstatus = files.Hblstatus,
                    Office = files.Office,
                    UserId = wnsid,

                };
            }
            return fhVM;
        }
        [HttpPost]
        public IActionResult Dashboard1(FileHBLMultiModule model)
        {
            return RedirectToAction("Dashboard", "User");
        }

        [HttpPost]
        public JsonResult Update_Value([FromBody] UpdateDataModel model)
        {
            string msg = "";
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
            if (model != null)
            {
                if (model.Id != "fileViewActionModel")
                {
                    if (model.Id == "pod")
                    {
                        _ctx.Hblmaster.First(x => x.Hblno == model.HBLno).Pod = model.Value;
                        _ctx.SaveChanges();
                    }
                    else if (model.Id == "pld")
                    {
                        _ctx.Hblmaster.First(x => x.Hblno == model.HBLno).Pld = model.Value;
                        _ctx.SaveChanges();
                    }
                    else if (model.Id == "HblprocessingStatus")
                    {

                        _ctx.Hblmaster.First(x => x.Hblno == model.HBLno).HblprocessingStatus = model.Value;
                        _ctx.Hblmaster.First(x => x.Hblno == model.HBLno).HblprocessingDate = DateTime.Now;
                        _ctx.SaveChanges();
                    }
                    else if (model.Id == "Amsstatus")
                    {
                        _ctx.Hblmaster.First(x => x.Hblno == model.HBLno).Amsstatus = model.Value;
                        _ctx.Hblmaster.First(x => x.Hblno == model.HBLno).AmsprocessingDate = DateTime.Now;
                        _ctx.SaveChanges();
                    }
                    else if (model.Id == "InvoicingStatus")
                    {
                        _ctx.Hblmaster.First(x => x.Hblno == model.HBLno).InvoicingStatus = model.Value;
                        _ctx.Hblmaster.First(x => x.Hblno == model.HBLno).InvoicingDate = DateTime.Now.ToString();
                        _ctx.SaveChanges();
                    }
                    else if (model.Id == "Hblcomments")
                    {
                        _ctx.Hblmaster.First(x => x.Hblno == model.HBLno).Hblcomments = model.Value;
                        _ctx.SaveChanges();
                    }
                    else if (model.Id == "Amscomments")
                    {
                        _ctx.Hblmaster.First(x => x.Hblno == model.HBLno).Amscomments = model.Value;
                        _ctx.SaveChanges();
                    }
                    else if (model.Id == "InvoicingComments")
                    {
                        _ctx.Hblmaster.First(x => x.Hblno == model.HBLno).InvoicingComments = model.Value;
                        _ctx.SaveChanges();
                    }
                    else if (model.Id == "HblAdded")
                    {
                        var hblfound = _ctx.Hblmaster.Where(x => x.Hblno == model.HBLno && x.FileNumber == model.Filenumber).FirstOrDefault();
                        if (hblfound == null)
                        {
                            Hblmaster hbl = new Hblmaster()
                            {
                                Hblno = model.HBLno,
                                FileNumber = model.Filenumber,
                                UserId = wnsid
                            };

                            _ctx.Hblmaster.Add(hbl);
                            _ctx.SaveChanges();
                        }
                        else
                        {
                            msg = "HBL aleready Added";
                        }
                    }
                    else if (model.Id == "hblnumber")
                    {
                        string[] getvalue = model.HblOrder.Split('_');

                        string ordervalue = getvalue[1];

                        var res = _ctx.Hblmaster.Where(x => (x.Hblno == model.HBLno) && x.FileNumber == model.Key).FirstOrDefault();
                        if (res == null)
                        {

                            Hblmaster hbl = new Hblmaster()
                            {
                                Hblno = model.HBLno,
                                FileNumber = model.Key,
                                UserId = wnsid
                            };

                            _ctx.Hblmaster.Add(hbl);
                            _ctx.SaveChanges();
                        }
                        else
                        {
                            msg = "already available";
                        }

                    }
                    else if (model.Id == "btnfilesave")
                    {
                        if (model.Value == "EtaChanged")
                        {
                            FileMaster file = _ctx.FileMaster.Where(x => x.FileNumber == model.Filenumber).FirstOrDefault();
                            file.PreviousEta = file.Eta;
                            file.NewEta = Convert.ToDateTime(model.Key);
                            file.Eta = Convert.ToDateTime(model.Key);
                            file.FileStartTime = null;
                            file.EtaChangedBy = wnsid;
                            file.EtaChangedDatetime = DateTime.Now;
                            file.EtaChangedComment = "EtaChanged";
                            _ctx.FileMaster.Update(file);
                            _ctx.SaveChanges();

                            msg = "Eta Changes Sucessfully! Click on Get Next";
                        }
                        else
                        {

                            msg = "file status updated";
                        }
                        _ctx.SaveChanges();
                    }
                }
            }
            if (msg == "")
            {
                return null;
            }
            else
            {
                return Json(msg);
            }

        }

        [HttpPost]
        public JsonResult LoadEmployees([FromBody] FileHBLMultiModule vm)
        {
            return null;
        }

        [HttpPost]
        public JsonResult SaveFileData([FromBody] List<HBLMasterViewModel> th)
        {
            string Msg = "";
            string Filestatus = "";
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();

            List<string> duplicatehbl = new List<string>();

            try
            {
                if (th.Count > 0)
                {
                    List<string> ustatus = new List<string>();
                    FileMaster fm = new FileMaster()
                    {
                        FileNumber = th[0].FileNumber,
                        Container = th[0].Container,
                        Mbl = th[0].Mbl,
                        Hblcount = th[0].Hblcount,
                        Pol = th[0].Pol,
                        Pod = th[0].Pod,
                        Eta = th[0].Eta,
                        Office = th[0].Office,
                        FileType = th[0].FileType,
                        //ContactPerson =th[0].c
                        UserId = th[0].UserId,
                        //CreateDateTime { get; set; }
                        Hbluser = "",
                        Hblstatus = th[0].Hblstatus,

                        EtaChangedBy = string.Empty,
                        EtaChangedComment = string.Empty,
                        //EtaChangedDatetime =

                    };

                    if (fm.Hblstatus == "Select")
                    {
                        Msg = "Please select filestatus";

                    }
                    else
                    {
                        foreach (HBLMasterViewModel hbl in th)
                        {
                            if (hbl.Hblno == null || hbl.Hblno == "")
                            {
                                //Msg = Msg + "," + i;
                            }
                            else
                            {
                                var hblfound = _ctx.Hblmaster.Where(x => x.Hblno == hbl.Hblno).FirstOrDefault();
                                if (hblfound != null)
                                {
                                    try
                                    {

                                        Hblmaster hblhm = new Hblmaster();
                                        hblhm.Hblno = hbl.Hblno;
                                        hblhm.Pod = hbl.Pod;
                                        hblhm.Pld = hbl.Pld;
                                        hblhm.FileNumber = hbl.FileNumber;
                                        hblhm.UserId = userid;
                                        hblhm.CreateDate = hbl.CreateDate;
                                        hblhm.HblprocessingStatus = hbl.HblprocessingStatus;
                                        hblhm.HblprocessingDate = hbl.HblprocessingDate;
                                        hblhm.Hblcomments = hbl.Hblcomments;
                                        hblhm.Amsstatus = hbl.Amsstatus;
                                        hblhm.AmsprocessingDate = hbl.AmsprocessingDate;
                                        hblhm.Amscomments = hbl.Amscomments;
                                        hblhm.InvoicingStatus = hbl.InvoicingStatus;
                                        hblhm.InvoicingDate = hbl.InvoicingDate;
                                        hblhm.InvoicingComments = hbl.InvoicingComments;

                                        var myData = _ctx.Hblmaster.Where(x => x.Hblno == hbl.Hblno).ToList();
                                        myData.ForEach(m => m.HblprocessingStatus = hbl.HblprocessingStatus);
                                        myData.ForEach(m => m.HblprocessingDate = hbl.HblprocessingDate);
                                        myData.ForEach(m => m.Hblcomments = hbl.Hblcomments);

                                        myData.ForEach(m => m.Amsstatus = hbl.Amsstatus);
                                        myData.ForEach(m => m.AmsprocessingDate = hbl.AmsprocessingDate);
                                        myData.ForEach(m => m.Amscomments = hbl.Amscomments);

                                        myData.ForEach(m => m.InvoicingStatus = hbl.InvoicingStatus);
                                        myData.ForEach(m => m.InvoicingDate = hbl.InvoicingDate);
                                        myData.ForEach(m => m.InvoicingComments = hbl.InvoicingComments);
                                        _ctx.SaveChanges();

                                        duplicatehbl.Add(hbl.Hblno);
                                        //_ctx.Hblmaster.Update(hblhm);

                                        //_ctx.Attach(hm);
                                        //_ctx.Entry(hm).State = EntityState.Modified;
                                        //_ctx.Hblmaster.Update(hm);
                                        //_ctx.SaveChanges();
                                    }
                                    catch (Exception ex)
                                    {
                                        Msg = ex.Message;
                                    }

                                }
                                else
                                {
                                    var hm = new Hblmaster()
                                    {
                                        Hblno = hbl.Hblno,
                                        Pod = hbl.Pod,
                                        Pld = hbl.Pld,
                                        FileNumber = hbl.FileNumber,
                                        UserId = userid,
                                        CreateDate = hbl.CreateDate,

                                        HblprocessingStatus = hbl.HblprocessingStatus,
                                        HblprocessingDate = hbl.HblprocessingDate,
                                        Hblcomments = hbl.Hblcomments,
                                        Amsstatus = hbl.Amsstatus,
                                        AmsprocessingDate = hbl.AmsprocessingDate,
                                        Amscomments = hbl.Amscomments,
                                        InvoicingStatus = hbl.InvoicingStatus,
                                        InvoicingDate = hbl.InvoicingDate,
                                        InvoicingComments = hbl.InvoicingComments
                                    };
                                    _ctx.Hblmaster.Add(hm);
                                    _ctx.SaveChanges();
                                }


                                if (hbl.HblprocessingStatus == "Select" || hbl.Amsstatus == "Select" || hbl.InvoicingStatus == "Select")
                                {
                                    Filestatus = "Select";
                                }
                                else if (hbl.HblprocessingStatus == "Pending" || hbl.Amsstatus == "Pending" || hbl.InvoicingStatus == "Pending")
                                {
                                    Filestatus = "Pending";
                                }
                                else if (hbl.HblprocessingStatus == "Query" || hbl.Amsstatus == "Query" || hbl.InvoicingStatus == "Query")
                                {
                                    Filestatus = "Query";
                                }
                                else if (hbl.HblprocessingStatus == "Completed" || hbl.Amsstatus == "Completed" || hbl.InvoicingStatus == "Completed")
                                {
                                    Filestatus = "Completed";
                                }
                            }
                        }

                        if (fm.Hblstatus == "EtaChanged")
                        {
                            FileMaster fl = _ctx.FileMaster.Where(x => x.FileNumber == fm.FileNumber).FirstOrDefault();
                            fl.Eta = Convert.ToDateTime(fm.Eta);
                            fl.Hblstatus = null;
                            fl.Hbluser = null;
                            fl.FileStartTime = null;
                            _ctx.FileMaster.Update(fl);
                            _ctx.SaveChanges();

                            Msg = "Eta Changes Sucessfully! Click on Get Next";
                        }
                    }

                    if (fm.Hblstatus == "Pending" || Filestatus == "Pending")
                    {
                        if (fm.Hblstatus == "Completed")
                        {
                            Filestatus = "Pending";
                            FileMaster fl = _ctx.FileMaster.Where(x => x.FileNumber == fm.FileNumber).FirstOrDefault();
                            fl.Hblstatus = "Pending";
                            fl.FileComplitionDate = DateTime.Now;
                            _ctx.FileMaster.Update(fl);
                            _ctx.SaveChanges();
                            Msg = "File Status Pending ..! Click on Get Next";
                        }
                        else
                        {
                            FileMaster fl = _ctx.FileMaster.Where(x => x.FileNumber == fm.FileNumber).FirstOrDefault();
                            fl.Hblstatus = "Pending";
                            fl.FileComplitionDate = DateTime.Now;
                            _ctx.FileMaster.Update(fl);
                            _ctx.SaveChanges();
                            Msg = "File Save Sucessfully..! Click on Get Next";
                        }

                    }
                    else if (fm.Hblstatus == "Query")
                    {
                        FileMaster fl = _ctx.FileMaster.Where(x => x.FileNumber == fm.FileNumber).FirstOrDefault();
                        fl.Hblstatus = "Query";
                        fl.FileComplitionDate = DateTime.Now;
                        _ctx.FileMaster.Update(fl);
                        _ctx.SaveChanges();
                        Msg = "File Save Sucessfully..! Click on Get Next";
                    }
                    else if (fm.Hblstatus == "Completed" && Filestatus == "Completed")
                    {
                        FileMaster fl = _ctx.FileMaster.Where(x => x.FileNumber == fm.FileNumber).FirstOrDefault();
                        fl.Hblstatus = fm.Hblstatus;
                        fl.FileComplitionDate = DateTime.Now;
                        fl.QcStatus = "Send to Qc";
                        _ctx.SaveChanges();
                        Msg = "File Save Sucessfully.Click on Get Next";
                    }
                }

                //foreach(string duphbl in duplicatehbl)
                //{
                //    Msg=Msg+" "+duphbl;
                //}


                if (Msg == "")
                {
                    return null;
                }
                else
                {
                    return Json(Msg);
                }
            }
            catch (Exception ex)
            {
                if (ex.InnerException.Message.Contains("Cannot insert duplicate key in object"))
                {
                    Msg = "Can't insert duplicate hbl number";
                }
                if (Msg == "")
                {
                    return null;
                }
                else
                {
                    return Json(Msg);
                }
            }
        }

        [HttpGet]
        public JsonResult GetNextFile()
        {
            FileViewModel vm = new FileViewModel();
            try
            {
                var username = _httpContextAccessor.HttpContext.User.Identity.Name;
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                var result = _ctx.FileMaster.Where(x => x.Hblstatus == null).Select(x => x).FirstOrDefault();

                if (result != null)
                {
                    vm = new FileViewModel
                    {
                        FileNumber = result.FileNumber,
                        Container = result.Container,
                        Mbl = result.Mbl,
                        Eta = result.Eta,
                        Pol = result.Pol,
                        Pod = result.Pol,
                        Hblcount = result.Hblcount,
                        FileType = result.FileType,
                        Hblstatus = result.Hblstatus,
                        Office = result.Office,
                        UserId = userid,
                    };
                }
            }
            catch (Exception ex)
            {

            }
            return Json(vm);
        }

        //PreAlert    
        public IActionResult UserPreAlert()
        {
            ViewData["Users"] = _ctx.UserMaster.Where(x => x.IsActive == true).Select(x => new UserMasterModel
            {
                Id = x.Id,
                UserName = x.UserName

            }).ToList();
            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).ToList();

            ViewData["ContactPersonList"] = _ctx.DispositionMaster.Select(x => new ContactPersonModel
            {
                Name = x.Name,
                Code = x.Code
            }).ToList();

            return View();
        }
        [HttpPost]
        public JsonResult UserPreAlert([FromBody] string Next)
        {
            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).ToList();

            ViewData["ContactPersonList"] = _ctx.DispositionMaster.Select(x => new ContactPersonModel
            {
                Name = x.Name,
                Code = x.Code
            }).ToList();

            if (RouteData.Values.TryGetValue("action", out var nextValue))
            {
                Next = nextValue.ToString();
                // Use the "Next" value in your logic
                // ...
            }

            PreAlertMasterViewModel premodel = new PreAlertMasterViewModel();
            PreAlertMaster file = new PreAlertMaster();
            string Msg = string.Empty;
            try
            {
                if (Next != null)
                {
                    var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

                    var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
                    var allocate = _ctx.PreAlertMaster.Where(x => x.Status == "Pending" && x.FuserId == userid && x.Status != "Missing").OrderBy(x => x.Eta).FirstOrDefault();

                    if (allocate != null)
                    {
                        var hbls = _ctx.Hblmaster.Where(x => x.FileNumber == allocate.FileNumber).ToList();
                        premodel = new PreAlertMasterViewModel
                        {
                            FileNumber = allocate.FileNumber,
                            Container = allocate.Container,
                            Mbl = allocate.Mbl,
                            Hblcount = allocate.Hblcount,
                            Pol = allocate.Pol,
                            Pod = allocate.Pod,
                            Eta = allocate.Eta,
                            FileType = allocate.FileType,
                            FuserId = _ctx.Users.Where(y => y.Id == allocate.FuserId).Select(y => y.UserName).FirstOrDefault(),
                            Remarks = allocate.Remarks,
                            RecievedDate = allocate.RecievedDate,
                            Office = allocate.Office,
                            Status = allocate.Status,
                            ContractPerson = allocate.ContractPerson
                        };
                    }
                    else
                    {
                        var location = _ctx.UserOfficeRelation.Where(x => x.UserId == userid).OrderBy(x => x.Order).ToList();

                        var officename = _ctx.OfficeMaster.Where(x => x.Id == location.First().OfficeId).Select(x => x.OfficeName).SingleOrDefault();

                        //var officename_2 = _ctx.OfficeMaster.Where(x => x.Id == location[1].OfficeId).Select(x => x.OfficeName).SingleOrDefault();

                        var file_primary = _ctx.PreAlertMaster.OrderBy(x => x.Eta).Where(x => x.Status == "" && x.Office == officename).FirstOrDefault();
                        //var file_secondary = _ctx.FileMaster.OrderBy(x => x.Eta).Where(x => x.QcStatus == "Send to Qc" && x.Eta != null && x.Office == officename_2).FirstOrDefault();


                        if (file_primary != null)
                        {
                            file = _ctx.PreAlertMaster.Where(x => x.Status == "" && x.Eta != null && x.Office == officename).OrderBy(x => x.Eta).FirstOrDefault();
                        }
                        else
                        {

                            file = _ctx.PreAlertMaster.Where(x => x.Status == "" || x.Status == null).OrderBy(x => x.Eta).FirstOrDefault();
                        }

                        if (file != null)
                        {
                            file.Status = "Pending";
                            file.FuserId = userid;
                            _ctx.PreAlertMaster.Update(file);
                            _ctx.SaveChanges();

                            //premodel = new PreAlertMasterViewModel
                            //{
                            //    FileNumber = file.FileNumber,
                            //    Container = file.Container,
                            //    Mbl = file.Mbl,
                            //    Hblcount = file.Hblcount,
                            //    Pol = file.Pol,
                            //    Pod = file.Pod,
                            //    Eta = file.Eta,
                            //    FileType = file.FileType,
                            //    Status = file.Status,
                            //    UserId=file.UserId,
                            //    FuserId=_ctx.Users.Where(y => y.Id == file.FuserId).Select(y => y.UserName).FirstOrDefault(),
                            //    Remarks=allocate.Remarks,
                            //    RecievedDate=allocate.RecievedDate,
                            //    Office=allocate.Office,

                            //};
                        }
                        else
                        {
                            Msg = ("No Data for pre-alert");
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            if (file.Id.ToString() != "00000000-0000-0000-0000-000000000000")
            {
                return Json(file);
            }
            else
            {
                return Json(premodel);
            }


        }

        public IActionResult PreAlertGetNext([FromRoute] string Next)
        {
            ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
            {
                Id = x.Id,
                OfficeName = x.OfficeName

            }).ToList();

            ViewData["ContactPersonList"] = _ctx.DispositionMaster.Select(x => new ContactPersonModel
            {
                Name = x.Name,
                Code = x.Code
            }).ToList();

            if (RouteData.Values.TryGetValue("action", out var nextValue))
            {
                Next = nextValue.ToString();
                // Use the "Next" value in your logic
                // ...
            }

            PreAlertMasterViewModel premodel = new PreAlertMasterViewModel();
            string Msg = string.Empty;
            try
            {
                if (Next != null)
                {
                    var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

                    var wnsid = _ctx.Users.Where(x => x.Id == userid).Select(x => x.Wnsid).SingleOrDefault();
                    var allocate = _ctx.PreAlertMaster.Where(x => x.Status == "Pending" && x.FuserId == userid).OrderBy(x => x.Eta).FirstOrDefault();

                    if (allocate != null)
                    {
                        var hbls = _ctx.Hblmaster.Where(x => x.FileNumber == allocate.FileNumber).ToList();
                        premodel = new PreAlertMasterViewModel
                        {
                            FileNumber = allocate.FileNumber,
                            Container = allocate.Container,
                            Mbl = allocate.Mbl,
                            Hblcount = allocate.Hblcount,
                            Pol = allocate.Pol,
                            Pod = allocate.Pod,
                            Eta = allocate.Eta,
                            FileType = allocate.FileType,
                            FuserId = _ctx.Users.Where(y => y.Id == allocate.FuserId).Select(y => y.UserName).FirstOrDefault(),
                            Remarks = allocate.Remarks,
                            RecievedDate = allocate.RecievedDate,
                            Office = allocate.Office,
                            Status = allocate.Status,
                            ContractPerson = allocate.ContractPerson
                        };
                    }
                    else
                    {
                        var location = _ctx.UserOfficeRelation.Where(x => x.UserId == userid).OrderBy(x => x.Order).ToList();

                        var officename = _ctx.OfficeMaster.Where(x => x.Id == location.First().OfficeId).Select(x => x.OfficeName).SingleOrDefault();

                        //var officename_2 = _ctx.OfficeMaster.Where(x => x.Id == location[1].OfficeId).Select(x => x.OfficeName).SingleOrDefault();

                        var file_primary = _ctx.PreAlertMaster.OrderBy(x => x.Eta).Where(x => x.Status == "" && x.Office == officename).FirstOrDefault();
                        //var file_secondary = _ctx.FileMaster.OrderBy(x => x.Eta).Where(x => x.QcStatus == "Send to Qc" && x.Eta != null && x.Office == officename_2).FirstOrDefault();
                        PreAlertMaster file = new PreAlertMaster();

                        if (file_primary != null)
                        {
                            file = _ctx.PreAlertMaster.Where(x => x.Status == "" && x.Eta != null && x.Office == officename).OrderBy(x => x.Eta).FirstOrDefault();
                        }
                        else
                        {

                            file = _ctx.PreAlertMaster.Where(x => x.Status == "" || x.Status == null).OrderBy(x => x.Eta).FirstOrDefault();
                        }

                        if (file != null)
                        {
                            file.Status = "Pending";
                            file.FuserId = userid;
                            _ctx.PreAlertMaster.Update(file);
                            _ctx.SaveChanges();

                            premodel = new PreAlertMasterViewModel
                            {
                                FileNumber = file.FileNumber,
                                Container = file.Container,
                                Mbl = file.Mbl,
                                Hblcount = file.Hblcount,
                                Pol = file.Pol,
                                Pod = file.Pod,
                                Eta = file.Eta,
                                FileType = file.FileType,
                                Status = file.Status,
                                UserId = file.UserId,
                                FuserId = _ctx.Users.Where(y => y.Id == file.FuserId).Select(y => y.UserName).FirstOrDefault(),
                                Remarks = allocate.Remarks,
                                RecievedDate = allocate.RecievedDate,
                                Office = allocate.Office,
                                ContractPerson = allocate.ContractPerson

                            };
                        }
                        else
                        {
                            Msg = "No Data for pre-alert";
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }


            return View("UserPreAlert", premodel);
        }

        public JsonResult PreAlertEdit([FromBody] PreAlertMasterViewModel model)
        {
            string Msg = string.Empty;
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (model != null)
            {

                ViewData["ContactPersonList"] = _ctx.DispositionMaster.Select(x => new ContactPersonModel
                {
                    Name = x.Name,
                    Code = x.Code
                }).ToList();

                PreAlertMasterViewModel _PreAlertMasterViewModel = new PreAlertMasterViewModel();
                try
                {
                    if (model.Status.ToString() == "--Select--")
                    {
                        Msg = "Please select status";
                    }
                    else
                    {
                        var result = _ctx.PreAlertMaster.FirstOrDefault(x => x.Container == model.Container);

                        if (result != null)
                        {
                            result.FileNumber = model.FileNumber;
                            result.Hblcount = model.Hblcount;
                            result.RecievedDate = model.RecievedDate;
                            result.Office = model.Office;
                            result.Eta = model.Eta;
                            result.Status = model.Status;
                            result.Pol = model.Pol;
                            result.Pod = model.Pod;
                            result.ContractPerson = model.ContractPerson;
                            result.FileType = model.FileType;
                            result.FuserId = userid;
                            result.Remarks = model.Remarks;
                            result.ComplitionTime = DateTime.UtcNow;
                            result.UpdationTime = DateTime.UtcNow;
                            _ctx.PreAlertMaster.Update(result);
                            _ctx.SaveChanges();

                            if (model.Status == "Data Entry")
                            {
                                var fileMaster = new FileMaster
                                {
                                    Container = model.Container,
                                    FileNumber = model.FileNumber,
                                    Hblcount = model.Hblcount,
                                    RecievedDate = model.RecievedDate,
                                    Office = model.Office,
                                    Eta = model.Eta,
                                    Pol = model.Pol,
                                    Pod = model.Pod,
                                    ContactPerson = model.ContractPerson,
                                    FileType = model.FileType,
                                    CreateDateTime = model.CreatedDate,
                                };
                                // Add the FileMaster entity to the context and save changes
                                _ctx.FileMaster.Add(fileMaster);
                                _ctx.SaveChanges();
                            }

                            //PreAlertMaster Pre = new PreAlertMaster();
                            //Pre.FileNumber = model.FileNumber;
                            //Pre.Container = model.Container;
                            //Pre.Hblcount = model.Hblcount;
                            //Pre.RecievedDate = model.RecievedDate;
                            //Pre.Office = model.Office;
                            //Pre.Eta = model.Eta;
                            //Pre.Status=model.Status;
                            //Pre.Pol=model.Pol;
                            //Pre.Pod=model.Pod;
                            //Pre.ContractPerson=model.ContractPerson;
                            //Pre.FileType=model.FileType;
                            //Pre.UserId=model.UserId;
                            //Pre.FuserId=model.UserId;
                            //Pre.Remarks=model.Remarks;
                            //Pre.Priority=model.Priority;                    

                            Msg = "Pre-Aleret Update Successfully!";
                        }

                    }

                    ViewData["Offices"] = _ctx.OfficeMaster.Select(x => new OfficeMasterViewModel
                    {
                        Id = x.Id,
                        OfficeName = x.OfficeName

                    }).ToList();

                    ViewData["ContactPersonList"] = _ctx.DispositionMaster.Select(x => new ContactPersonModel
                    {
                        Name = x.Name,
                        Code = x.Code
                    }).ToList();

                }
                catch (Exception ex)
                {
                    Msg = ex.Message;
                }

            }

            return Json(Msg);
        }
    }
}
