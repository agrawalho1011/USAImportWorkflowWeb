﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Data
{
    public class UserOfficeRelation
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string? UserId { get; set; }
        public Guid? OfficeId { get; set; }
        public int Order { get; set; }
        public bool? IsActive { get; set; } = true;
    }
}
