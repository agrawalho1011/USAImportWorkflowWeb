﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace USAImportWorkflowWeb.Data
{
    public class ApplicationDbContext : IdentityDbContext<UserMaster>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
                : base(options)
        {

        }
		public virtual DbSet<OfficeMaster> OfficeMaster { get; set; }
		public virtual DbSet<UserMaster> UserMaster { get; set; }
        public virtual DbSet<UserOfficeMaster> UserOfficeMaster { get; set; }
        public virtual DbSet<UserOfficeRelation> UserOfficeRelation { get; set; }
		public virtual DbSet<Digiview> Digiview { get; set; }

		
		public virtual DbSet<FileMaster> FileMaster { get; set; }
		public virtual DbSet<Hblmaster> Hblmaster { get; set; }
		public virtual DbSet<Hblprocessing> Hblprocessing { get; set; }
		public virtual DbSet<ImportCoOrdinator> ImportCoOrdinator { get; set; }
				
		public virtual DbSet<PreAlertMaster> PreAlertMaster { get; set; }
		public virtual DbSet<QcHblWiseData> QcHblWiseData { get; set; }
		public virtual DbSet<QcMaster> QcMaster { get; set; }
		public virtual DbSet<DispositionMaster> DispositionMaster { get; set; }
		public virtual DbSet<DocContactMaster> DocContactMaster { get; set; }

		protected override void OnModelCreating(ModelBuilder builder)
		{
			base.OnModelCreating(builder);

			builder.Entity<UserMaster>().Ignore(x => x.PasswordHash).Ignore(c => c.PhoneNumber).Ignore(c => c.PhoneNumberConfirmed).Ignore(c => c.TwoFactorEnabled).Ignore(c => c.Email).Ignore(c => c.EmailConfirmed).Ignore(c => c.NormalizedEmail).Ignore(c => c.LockoutEnabled).Ignore(c => c.LockoutEnd).Ignore(c => c.PasswordHash);

			builder.Entity<Digiview>(entity =>
			{
				entity.HasKey(e => e.Hblno);				
			});

			builder.Entity<DispositionMaster>(entity => {
				entity.HasKey(e => e.Name);
			});

			builder.Entity<FileMaster>(entity =>
			{
				entity.HasKey(e => e.FileNumber);

				entity.Property(e => e.FileNumber).HasMaxLength(20);

			});

			
			builder.Entity<Hblmaster>(entity =>
			{
				entity.HasKey(e => e.Hblno);
				entity.ToTable(name: "HBLMaster");
			});

			builder.Entity<Hblprocessing>(entity =>
			{
				entity.HasKey(e => e.ActivtyId);

				entity.ToTable("HBLProcessing");
				
			});
			
			builder.Entity<ImportCoOrdinator>(entity =>
			{
				entity.HasKey(e => e.ActivityId);

				entity.Property(e => e.ActivityId)
					.HasColumnName("ActivityID")
					.HasMaxLength(255);

			});

			builder.Entity<UserMaster>(entity =>
			{
				entity.ToTable(name: "User");
			});

			builder.Entity<IdentityRole>(entity =>
			{
				entity.ToTable(name: "Role");
			});
			builder.Entity<IdentityUserRole<string>>(entity =>
			{
				entity.ToTable("UserRoles");
				//in case you chagned the TKey type
				//  entity.HasKey(key => new { key.UserId, key.RoleId });
			});


			builder.Entity<IdentityUserClaim<string>>(entity =>
			{
				entity.ToTable("UserClaims");
			});

			builder.Entity<IdentityUserLogin<string>>(entity =>
			{
				entity.ToTable("UserLogins");
				//in case you chagned the TKey type
				//  entity.HasKey(key => new { key.ProviderKey, key.LoginProvider });       
			});

			builder.Entity<IdentityRoleClaim<string>>(entity =>
			{
				entity.ToTable("RoleClaims");

			});

			builder.Entity<IdentityUserToken<string>>(entity =>
			{
				entity.ToTable("UserTokens");
				//in case you chagned the TKey type
				// entity.HasKey(key => new { key.UserId, key.LoginProvider, key.Name });

			});
			
		}



		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			//optionsBuilder.UseLazyLoadingProxies();
			base.OnConfiguring(optionsBuilder);
		}

	}
}
