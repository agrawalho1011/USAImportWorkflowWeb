﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;


namespace USAImportWorkflowWeb.Data
{
    public partial class UserMaster : IdentityUser
    {
        public UserMaster()
        {
            UserOfficeMasters = new HashSet<UserOfficeMaster>();

        }

        public override string Id { get; set; } = Guid.NewGuid().ToString();
        public override string? UserName { get; set; }
        public string? Wnsid { get; set; }
        public string? CitrixId { get; set; }
        public string? Doc_Contact { get; set; }
        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;

        public virtual ICollection<UserOfficeMaster> UserOfficeMasters { get; set; }

    }
}
