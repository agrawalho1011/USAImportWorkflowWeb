﻿using System;
using System.ComponentModel.DataAnnotations;

namespace USAImportWorkflowWeb.Data
{
    public class reportdownload
    {
        [Required]
        public string FileNumber { get; set; }
        [Required]
        public string Container { get; set; }
        public DateTime? RecievedDate { get; set; }
        public string UserId { get; set; }
        public string Hblstatus { get; set; }
        public int? Hblcount { get; set; }
        public DateTime? Eta { get; set; }
        public string Office { get; set; }
        public DateTime? FileComplitionDate { get; set; }
        public DateTime? PreviousEta { get; set; }
        public string EtaChangedBy { get; set; }
        public DateTime? CreateDateTime { get; set; }
        public string EtaChangedComment { get; set; }
        public DateTime? EtaChangedDatetime { get; set; }
    }
}
