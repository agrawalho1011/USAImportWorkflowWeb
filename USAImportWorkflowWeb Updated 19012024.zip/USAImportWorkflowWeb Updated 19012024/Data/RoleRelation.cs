﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace USAImportWorkflowWeb.Data
{
    public partial class RoleRelation
    {
        public int RoleRelationId { get; set; }
        public int? RoleId { get; set; }
        public string UserId { get; set; }

        public virtual Role Role { get; set; }
        public virtual UserMaster User { get; set; }
    }
}
