﻿using System;
using System.ComponentModel.DataAnnotations;

namespace USAImportWorkflowWeb.Data
{
    public class DispositionMaster
    {
        [Key]
        public string Name { get; set; }
        public string Code { get; set; }
    }
}
