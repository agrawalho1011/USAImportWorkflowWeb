﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace USAImportWorkflowWeb.Migrations
{
    public partial class AdddispositionMaster : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
